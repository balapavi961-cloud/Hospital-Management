const pool = require('./src/config/db');

async function createTestLabPrescriptionWithImage() {
    try {
        console.log('Creating test laboratory prescription with proper data...\n');

        // Get or create a test appointment
        let appointmentId;
        const [appointments] = await pool.query(
            'SELECT id, patient_name FROM appointments LIMIT 1'
        );

        if (appointments.length === 0) {
            console.log('Creating test appointment...');
            await pool.query(`
                INSERT INTO appointments (patient_name, age, gender, contact_number, doctor, date, time, type, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                'John Doe',
                45,
                'Male',
                '9876543210',
                'Dr. Smith',
                '2026-01-22',
                '11:00 AM',
                'Laboratory Test',
                'in-progress'
            ]);

            const [newAppt] = await pool.query('SELECT LAST_INSERT_ID() as id');
            appointmentId = newAppt[0].id;
            console.log(`✓ Created appointment ID: ${appointmentId}`);
        } else {
            appointmentId = appointments[0].id;
            console.log(`✓ Using existing appointment ID: ${appointmentId} (${appointments[0].patient_name})`);
        }

        // Create a laboratory prescription with proper columns
        const [result] = await pool.query(`
            INSERT INTO prescriptions (appointment_id, image_path, prescription_type, status, created_at)
            VALUES (?, ?, ?, ?, NOW())
        `, [
            appointmentId,
            'uploads/prescriptions/test-lab-prescription-' + Date.now() + '.png',
            'laboratory',
            'pending'
        ]);

        console.log('\n✅ Test laboratory prescription created successfully!');
        console.log(`\nDetails:`);
        console.log(`  Prescription ID: ${result.insertId}`);
        console.log(`  Appointment ID: ${appointmentId}`);
        console.log(`  Type: laboratory`);
        console.log(`  Status: pending`);
        console.log(`\n📋 This prescription should now appear in the laboratory portal!`);
        console.log(`   Go to: http://localhost:5173/dashboard/laboratory/prescriptions\n`);

        // Verify it's queryable
        const [verify] = await pool.query(`
            SELECT p.*, a.patient_name, a.age, a.gender, a.doctor
            FROM prescriptions p
            LEFT JOIN appointments a ON p.appointment_id = a.id
            WHERE p.prescription_type = 'laboratory'
            ORDER BY p.created_at DESC
            LIMIT 1
        `);

        if (verify.length > 0) {
            console.log('✓ Verification: Prescription is queryable by lab portal');
            console.log(`  Patient: ${verify[0].patient_name}`);
            console.log(`  Doctor: ${verify[0].doctor}`);
        }

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

createTestLabPrescriptionWithImage();
