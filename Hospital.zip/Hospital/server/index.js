require('dotenv').config();
const app = require('./src/app');
app.use('/api/nurse', require('./src/routes/nurse.routes'));
app.use('/api/staff', require('./src/routes/staff.routes'));
app.use('/api/receptionist', require('./src/routes/receptionist.routes'));
app.use('/api/doctor', require('./src/routes/doctor.routes'));
app.use('/api/auth', require('./src/routes/auth.routes'));
app.use('/api/departments', require('./src/routes/department.routes'));
app.use('/api/prescriptions', require('./src/routes/prescription.routes'));
app.use('/api/referrals', require('./src/routes/referral.routes'));
const pool = require('./src/config/db');

const PORT = process.env.PORT || 5000;

const startServer = async () => {
    try {
        // Test DB Connection
        await pool.getConnection();
        console.log('✅ Database connected successfully');

        app.listen(PORT, () => {
            console.log(`🚀 Server running on port ${PORT}`);
        });
    } catch (error) {
        console.error('❌ Database connection failed:', error.message);
        process.exit(1);
    }
};

startServer();
