const fs = require('fs');
const path = require('path');
const pool = require('./src/config/db');

async function createTestWithReports() {
    try {
        console.log('Creating test prescription with reports...\n');

        // Ensure directories exist
        const labReportsDir = path.join(__dirname, 'uploads/lab-reports');
        if (!fs.existsSync(labReportsDir)) {
            fs.mkdirSync(labReportsDir, { recursive: true });
            console.log('✓ Created lab-reports directory');
        }

        // Create test image files (1x1 pixel PNG)
        const testImageBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
        const imageBuffer = Buffer.from(testImageBase64, 'base64');

        const reportPaths = [];
        for (let i = 1; i <= 3; i++) {
            const fileName = `test-report-${i}-${Date.now()}.png`;
            const filePath = path.join(labReportsDir, fileName);
            fs.writeFileSync(filePath, imageBuffer);
            reportPaths.push(`uploads/lab-reports/${fileName}`);
            console.log(`✓ Created test report ${i}: ${fileName}`);
        }

        // Find or create a lab prescription
        let [prescriptions] = await pool.query(`
            SELECT id FROM prescriptions 
            WHERE prescription_type = 'laboratory' 
            LIMIT 1
        `);

        let prescriptionId;
        if (prescriptions.length === 0) {
            // Create test appointment and prescription
            await pool.query(`
                INSERT INTO appointments (patient_name, age, gender, contact_number, doctor, date, time, type, status)
                VALUES ('Test Patient', 30, 'Male', '1234567890', 'Dr. Test', '2026-01-22', '2:00 PM', 'Lab Test', 'in-progress')
            `);

            const [appt] = await pool.query('SELECT LAST_INSERT_ID() as id');
            const appointmentId = appt[0].id;

            await pool.query(`
                INSERT INTO prescriptions (appointment_id, prescription_type, status, created_at)
                VALUES (?, 'laboratory', 'pending', NOW())
            `, [appointmentId]);

            const [pres] = await pool.query('SELECT LAST_INSERT_ID() as id');
            prescriptionId = pres[0].id;
            console.log('✓ Created new test prescription');
        } else {
            prescriptionId = prescriptions[0].id;
            console.log(`✓ Using existing prescription ID: ${prescriptionId}`);
        }

        // Update prescription with test reports
        await pool.query(`
            UPDATE prescriptions 
            SET report_paths = ?, 
                lab_technician = 'Test Technician',
                report_uploaded_at = NOW()
            WHERE id = ?
        `, [JSON.stringify(reportPaths), prescriptionId]);

        console.log('\n✅ Test prescription created successfully!');
        console.log(`   Prescription ID: ${prescriptionId}`);
        console.log(`   Reports: ${reportPaths.length} files`);
        console.log('\n📱 Test in portals:');
        console.log(`   Laboratory: http://localhost:5173/dashboard/laboratory/prescriptions`);
        console.log(`   Doctor: http://localhost:5173/dashboard/doctor/appointments`);
        console.log('\n🔍 What to verify:');
        console.log(`   1. Lab portal shows ${reportPaths.length} uploaded reports`);
        console.log(`   2. Reports display in grid layout`);
        console.log(`   3. Doctor portal shows reports in "Lab Reports" section`);
        console.log(`   4. All images load correctly\n`);

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

createTestWithReports();
