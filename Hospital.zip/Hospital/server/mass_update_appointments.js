const pool = require('./src/config/db');

async function massUpdate() {
    try {
        console.log("🚀 Starting Mass Update of Appointments...");

        // 1. Ensure all appointments have a name
        await pool.query(`
            UPDATE appointments 
            SET patient_name = CONCAT('Patient ', id) 
            WHERE patient_name IS NULL OR patient_name = ''
        `);

        // 2. Ensure all have age and gender
        await pool.query(`
            UPDATE appointments 
            SET age = 25, gender = 'Female' 
            WHERE age IS NULL OR age = 0
        `);

        // 3. Ensure all have valid gender if null
        await pool.query(`
            UPDATE appointments 
            SET gender = 'Male' 
            WHERE gender IS NULL
        `);

        // 4. Link all appointments to a valid patient ID if possible (fallback to patient 1)
        // First, check if we have any patients
        const [patients] = await pool.query('SELECT id FROM patients LIMIT 1');
        if (patients.length > 0) {
            const pid = patients[0].id;
            await pool.query(`
                UPDATE appointments 
                SET patient_id = ? 
                WHERE patient_id IS NULL
            `, [pid]);
            console.log(`Linked orphaned appointments to patient ID ${pid}`);
        }

        // 5. Check results
        const [rows] = await pool.query('SELECT id, patient_name, age, gender FROM appointments LIMIT 5');
        console.log("Updated samples:", JSON.stringify(rows, null, 2));

        console.log("✅ Mass update complete.");

    } catch (error) {
        console.error("Error:", error);
    } finally {
        process.exit();
    }
}

massUpdate();
