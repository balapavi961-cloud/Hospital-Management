const pool = require('./src/config/db');

async function fixData() {
    try {
        console.log("🛠 Fixing missing data for appointments...");

        // Update appointments where age/gender is null
        await pool.query(`
            UPDATE appointments 
            SET age = 30, gender = 'Male', patient_name = COALESCE(patient_name, 'Unknown Patient')
            WHERE age IS NULL OR gender IS NULL OR patient_name IS NULL
        `);

        // Also ensure they have a patient_id linking to a patient (optional, but good for integrity)
        // For simplicity, we just force the data in the appointments table itself as that's the primary display source

        console.log("✅ Data updated successfully!");

    } catch (error) {
        console.error("Error fixing data:", error);
    } finally {
        process.exit();
    }
}

fixData();
