const pool = require('./src/config/db');

async function checkPrescriptionImages() {
    try {
        console.log('Checking laboratory prescriptions and their images...\n');

        const [prescriptions] = await pool.query(`
            SELECT id, appointment_id, image_path, prescription_type, status, created_at
            FROM prescriptions 
            WHERE prescription_type = 'laboratory'
            ORDER BY created_at DESC
            LIMIT 10
        `);

        console.log(`Found ${prescriptions.length} laboratory prescriptions:\n`);

        prescriptions.forEach(pres => {
            console.log(`ID: ${pres.id}`);
            console.log(`  Appointment: ${pres.appointment_id}`);
            console.log(`  Image Path: ${pres.image_path || 'NULL'}`);
            console.log(`  Status: ${pres.status}`);
            console.log(`  Created: ${pres.created_at}`);
            console.log('');
        });

        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

checkPrescriptionImages();
