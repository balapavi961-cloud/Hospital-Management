const pool = require('./src/config/db');

async function addPrescriptionStatusColumns() {
    try {
        console.log('Adding status columns to prescriptions table...');

        // Check if columns already exist
        const [existingColumns] = await pool.query(`
            SELECT COLUMN_NAME
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'hospital_management' 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME IN ('sent_to_pharmacy', 'sent_to_lab', 'sent_at')
        `);

        const existingColumnNames = existingColumns.map(col => col.COLUMN_NAME);

        // Add columns only if they don't exist
        if (!existingColumnNames.includes('sent_to_pharmacy')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN sent_to_pharmacy BOOLEAN DEFAULT FALSE`);
            console.log('✅ Added sent_to_pharmacy column');
        }

        if (!existingColumnNames.includes('sent_to_lab')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN sent_to_lab BOOLEAN DEFAULT FALSE`);
            console.log('✅ Added sent_to_lab column');
        }

        if (!existingColumnNames.includes('sent_at')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN sent_at TIMESTAMP NULL`);
            console.log('✅ Added sent_at column');
        }

        console.log('✅ Successfully added all status columns to prescriptions table');

        // Verify the changes
        const [columns] = await pool.query(`
            SELECT COLUMN_NAME, COLUMN_TYPE, COLUMN_DEFAULT
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'hospital_management' 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME IN ('sent_to_pharmacy', 'sent_to_lab', 'sent_at')
        `);

        console.log('New columns:', columns);

        process.exit(0);
    } catch (error) {
        console.error('Error adding status columns:', error);
        process.exit(1);
    }
}

addPrescriptionStatusColumns();
