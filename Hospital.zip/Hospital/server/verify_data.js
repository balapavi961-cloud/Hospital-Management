const pool = require('./src/config/db');

const verify = async () => {
    try {
        const [rows] = await pool.query('SELECT * FROM appointments');
        console.log('Appointments Count:', rows.length);
        console.log('Appointments:', JSON.stringify(rows, null, 2));

        const [patients] = await pool.query('SELECT * FROM patients');
        console.log('Patients Count:', patients.length);
        console.log('Patients:', JSON.stringify(patients, null, 2));

        process.exit(0);
    } catch (e) {
        console.error(e);
        process.exit(1);
    }
};

verify();
