// Native fetch used
const fetch = globalThis.fetch;

const testDepartments = async () => {
    try {
        console.log('Testing Department API...');

        // 1. Add Department
        const newDept = {
            name: 'Neurology',
            head: 'Dr. Strange',
            location: 'Block C, 3rd Floor',
            description: 'Brain and Nervous System'
        };

        const addResp = await fetch('http://localhost:5000/api/departments', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newDept)
        });

        if (!addResp.ok) throw new Error(`Add failed: ${addResp.status}`);
        const addData = await addResp.json();
        console.log('✅ Added Department:', addData);

        // 2. Get Departments
        const getResp = await fetch('http://localhost:5000/api/departments');
        if (!getResp.ok) throw new Error(`Get failed: ${getResp.status}`);
        const list = await getResp.json();

        console.log(`✅ Fetched ${list.length} departments.`);
        const found = list.find(d => d.name === 'Neurology');

        if (found) {
            console.log('✅ Verified: Neurology exists in list.');
        } else {
            throw new Error('❌ Verification failed: Neurology not found in list.');
        }

        process.exit(0);
    } catch (e) {
        console.error('❌ Error:', e.message);
        process.exit(1);
    }
};

testDepartments();
