const pool = require('./src/config/db');
const fs = require('fs');
const path = require('path');

async function testCompleteWorkflow() {
    try {
        console.log('🔍 Testing Complete Lab Report Workflow\n');
        console.log('='.repeat(60));

        // Step 1: Check database structure
        console.log('\n1️⃣ Checking Database Structure...');
        const [columns] = await pool.query(`
            SELECT COLUMN_NAME, DATA_TYPE 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME = 'prescriptions' 
            AND COLUMN_NAME IN ('image_path', 'report_paths', 'prescription_type', 'status')
        `);
        console.log('   Required columns:');
        columns.forEach(col => console.log(`   ✓ ${col.COLUMN_NAME} (${col.DATA_TYPE})`));

        // Step 2: Check for lab prescriptions
        console.log('\n2️⃣ Checking Laboratory Prescriptions...');
        const [labPrescriptions] = await pool.query(`
            SELECT id, appointment_id, image_path, report_paths, status, created_at
            FROM prescriptions 
            WHERE prescription_type = 'laboratory'
            ORDER BY created_at DESC
            LIMIT 5
        `);

        console.log(`   Found ${labPrescriptions.length} laboratory prescriptions\n`);

        labPrescriptions.forEach((pres, index) => {
            console.log(`   Prescription #${index + 1}:`);
            console.log(`   - ID: ${pres.id}`);
            console.log(`   - Appointment: ${pres.appointment_id}`);
            console.log(`   - Doctor's Prescription Image: ${pres.image_path || 'NULL'}`);
            console.log(`   - Lab Reports: ${pres.report_paths || 'NULL'}`);
            console.log(`   - Status: ${pres.status}`);

            // Validate report_paths
            if (pres.report_paths) {
                try {
                    const reports = JSON.parse(pres.report_paths);
                    if (Array.isArray(reports)) {
                        console.log(`   - ✓ Valid JSON array with ${reports.length} report(s)`);
                        reports.forEach((path, i) => {
                            const fullPath = `./` + path;
                            const exists = fs.existsSync(fullPath);
                            console.log(`     ${i + 1}. ${path} ${exists ? '✓ EXISTS' : '✗ MISSING'}`);
                        });
                    } else {
                        console.log(`   - ✗ Invalid: Not an array`);
                    }
                } catch (e) {
                    console.log(`   - ✗ Invalid JSON: ${e.message}`);
                }
            }

            // Check doctor's prescription image
            if (pres.image_path) {
                const imagePath = `./${pres.image_path}`;
                const exists = fs.existsSync(imagePath);
                console.log(`   - Doctor's image: ${exists ? '✓ EXISTS' : '✗ MISSING'}`);
            }

            console.log('');
        });

        // Step 3: Check uploads directory
        console.log('\n3️⃣ Checking Uploads Directory...');
        const uploadsDir = './uploads';
        const prescriptionsDir = path.join(uploadsDir, 'prescriptions');
        const labReportsDir = path.join(uploadsDir, 'lab-reports');

        console.log(`   Prescriptions folder: ${fs.existsSync(prescriptionsDir) ? '✓ EXISTS' : '✗ MISSING'}`);
        console.log(`   Lab reports folder: ${fs.existsSync(labReportsDir) ? '✓ EXISTS' : '✗ MISSING'}`);

        if (fs.existsSync(labReportsDir)) {
            const files = fs.readdirSync(labReportsDir);
            console.log(`   Lab report files: ${files.length}`);
            files.slice(0, 5).forEach(file => console.log(`     - ${file}`));
        }

        // Step 4: Summary
        console.log('\n' + '='.repeat(60));
        console.log('📊 SUMMARY\n');
        console.log(`✓ Database columns: OK`);
        console.log(`✓ Laboratory prescriptions: ${labPrescriptions.length} found`);
        console.log(`✓ Upload directories: ${fs.existsSync(labReportsDir) ? 'OK' : 'NEEDS CREATION'}`);

        const validPrescriptions = labPrescriptions.filter(p => {
            if (!p.report_paths) return false;
            try {
                const reports = JSON.parse(p.report_paths);
                return Array.isArray(reports) && reports.length > 0;
            } catch {
                return false;
            }
        });

        console.log(`✓ Prescriptions with valid reports: ${validPrescriptions.length}`);

        console.log('\n🎯 NEXT STEPS:');
        if (labPrescriptions.length === 0) {
            console.log('   1. Create a lab prescription from doctor portal');
            console.log('   2. Upload test reports in laboratory portal');
            console.log('   3. View reports in doctor appointment details');
        } else if (validPrescriptions.length === 0) {
            console.log('   1. Go to laboratory portal');
            console.log('   2. Upload test reports for existing prescriptions');
            console.log('   3. Verify display in both portals');
        } else {
            console.log('   ✓ System ready! Test the complete workflow:');
            console.log('     - Laboratory: View and upload reports');
            console.log('     - Doctor: View uploaded reports');
        }

        console.log('\n' + '='.repeat(60) + '\n');

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

testCompleteWorkflow();
