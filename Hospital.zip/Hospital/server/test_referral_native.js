const http = require('http');

const postData = JSON.stringify({
    patient_id: 1,
    source_doctor_id: 101,
    source_doctor_name: 'Dr. Test Source',
    target_doctor_id: 102,
    target_doctor_name: 'Dr. Test Target',
    reason: 'Test referral reason'
});

const options = {
    hostname: 'localhost',
    port: 5000,
    path: '/api/referrals',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
    }
};

console.log('--- Testing Referral API (Native) ---');
console.log('Sending Request...');

const req = http.request(options, (res) => {
    console.log(`STATUS: ${res.statusCode}`);
    res.setEncoding('utf8');
    let rawData = '';
    res.on('data', (chunk) => { rawData += chunk; });
    res.on('end', () => {
        try {
            const parsedData = JSON.parse(rawData);
            console.log('✅ Response:', parsedData);
            if (res.statusCode === 201) {
                console.log('✅ Success!');
            } else {
                console.log('❌ Failed with status', res.statusCode);
            }
        } catch (e) {
            console.error('❌ Failed to parse response:', e.message);
            console.log('Raw:', rawData);
        }
    });
});

req.on('error', (e) => {
    console.error(`❌ Problem with request: ${e.message}`);
});

// Write data to request body
req.write(postData);
req.end();
