const pool = require('./src/config/db');

async function updatePrescriptionsTable() {
    try {
        console.log('Starting prescriptions table update...');

        // Check if columns exist first
        const checkColumns = `
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME IN ('status', 'dispensed_by', 'dispensed_at', 'dispensing_notes')
        `;

        const [existingColumns] = await pool.query(checkColumns);
        const existingColumnNames = existingColumns.map(col => col.COLUMN_NAME);

        // Add status column if it doesn't exist
        if (!existingColumnNames.includes('status')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN status VARCHAR(20) DEFAULT 'pending'`);
            console.log('✓ Added status column');
        }

        // Add dispensed_by column if it doesn't exist
        if (!existingColumnNames.includes('dispensed_by')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN dispensed_by VARCHAR(255)`);
            console.log('✓ Added dispensed_by column');
        }

        // Add dispensed_at column if it doesn't exist
        if (!existingColumnNames.includes('dispensed_at')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN dispensed_at DATETIME`);
            console.log('✓ Added dispensed_at column');
        }

        // Add dispensing_notes column if it doesn't exist
        if (!existingColumnNames.includes('dispensing_notes')) {
            await pool.query(`ALTER TABLE prescriptions ADD COLUMN dispensing_notes TEXT`);
            console.log('✓ Added dispensing_notes column');
        }

        // Update existing prescriptions to have pending status
        await pool.query(`
            UPDATE prescriptions 
            SET status = 'pending' 
            WHERE status IS NULL OR status = ''
        `);
        console.log('✓ Updated existing prescriptions with pending status');

        console.log('Prescriptions table update completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('Error updating prescriptions table:', error);
        process.exit(1);
    }
}

updatePrescriptionsTable();
