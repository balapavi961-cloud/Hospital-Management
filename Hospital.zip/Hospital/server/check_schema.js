const pool = require('./src/config/db');

async function checkSchema() {
    try {
        const [columns] = await pool.query('DESCRIBE vitals');
        console.log(JSON.stringify(columns, null, 2));
    } catch (error) {
        console.error(error);
    } finally {
        process.exit();
    }
}

checkSchema();
