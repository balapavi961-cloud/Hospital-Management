const pool = require('./src/config/db');

const createTable = async () => {
    try {
        const query = `
            CREATE TABLE IF NOT EXISTS referrals (
                id INT AUTO_INCREMENT PRIMARY KEY,
                patient_id INT NOT NULL,
                source_doctor_id INT, 
                source_doctor_name VARCHAR(255),
                target_doctor_id INT,
                target_doctor_name VARCHAR(255),
                target_department_id INT,
                target_department_name VARCHAR(255),
                reason TEXT,
                status VARCHAR(20) DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        `;
        await pool.query(query);
        console.log('✅ Referrals table created successfully');
        process.exit(0);
    } catch (error) {
        console.error('❌ Error creating table:', error);
        process.exit(1);
    }
};

createTable();
