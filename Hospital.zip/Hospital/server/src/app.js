const express = require('express');
const cors = require('cors');
const path = require('path');
const nurseRoutes = require('./routes/nurse.routes');
const pharmacyRoutes = require('./routes/pharmacy.routes');
const laboratoryRoutes = require('./routes/laboratory.routes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve static files from uploads directory
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// Routes
app.use('/api/nurse', nurseRoutes);
app.use('/api/pharmacy', pharmacyRoutes);
app.use('/api/laboratory', laboratoryRoutes);

// Basic Route
app.get('/', (req, res) => {
    res.send('Hospital Management System API is running');
});

module.exports = app;
