const express = require('express');
const cors = require('cors');
const nurseRoutes = require('./routes/nurse.routes');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/nurse', nurseRoutes);

// Basic Route
app.get('/', (req, res) => {
    res.send('Hospital Management System API is running');
});

module.exports = app;
