const mysql = require('mysql2/promise');
require('dotenv').config();

const initDb = async () => {
  try {
    // Connect without database selected to create it
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
    });

    console.log('🔌 Connected to MySQL server');

    // Create Database
    await connection.query(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME}`);
    console.log(`✅ Database ${process.env.DB_NAME} check/creation successful`);

    await connection.end();

    // Reconnect with database selected
    const pool = require('./db');

    // Create Tables

    // Drop existing tables to ensure schema updates
    await pool.query('DROP TABLE IF EXISTS appointments');
    await pool.query('DROP TABLE IF EXISTS beds');
    await pool.query('DROP TABLE IF EXISTS vitals');
    await pool.query('DROP TABLE IF EXISTS patients');
    await pool.query('DROP TABLE IF EXISTS staff');

    const createPatientsTable = `
      CREATE TABLE IF NOT EXISTS patients (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        age INT NOT NULL,
        gender VARCHAR(50),
        contact_number VARCHAR(50),
        diagnosis TEXT,
        bed_number VARCHAR(50),
        admission_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        nurse_id INT,
        doctor_id INT
      )
    `;

    const createVitalsTable = `
      CREATE TABLE IF NOT EXISTS vitals (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT,
        blood_pressure VARCHAR(50),
        heart_rate INT,
        temperature DECIMAL(5,2),
        oxygen_level INT,
        respiratory_rate INT,
        height DECIMAL(5,2),
        weight DECIMAL(5,2),
        recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
      )
    `;

    const createBedsTable = `
      CREATE TABLE IF NOT EXISTS beds (
        id INT AUTO_INCREMENT PRIMARY KEY,
        bed_number VARCHAR(50) UNIQUE NOT NULL,
        ward VARCHAR(100),
        status ENUM('available', 'occupied', 'maintenance') DEFAULT 'available',
        patient_id INT NULL,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL
      )
    `;

    const createAppointmentsTable = `
      CREATE TABLE IF NOT EXISTS appointments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT,
        patient_name VARCHAR(255) NOT NULL,
        age INT,
        gender VARCHAR(50),
        contact_number VARCHAR(50),
        doctor VARCHAR(255),
        date VARCHAR(50),  -- Keeping as string for now to match frontend format easily, or DATE if format is YYYY-MM-DD
        time VARCHAR(50),
        type VARCHAR(100) DEFAULT 'General Checkup',
        status ENUM('upcoming', 'in-progress', 'waiting', 'completed', 'cancelled') DEFAULT 'upcoming',
        priority VARCHAR(50) DEFAULT 'Normal',
        symptoms TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE SET NULL
      ) AUTO_INCREMENT=1001;
    `;

    const createStaffTable = `
      CREATE TABLE IF NOT EXISTS staff (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        department VARCHAR(100),
        age INT,
        contact_number VARCHAR(50),
        email VARCHAR(100),
        place VARCHAR(100),
        state VARCHAR(100),
        district VARCHAR(100),
        thaluk VARCHAR(100),
        joining_date DATE,
        shift_time VARCHAR(100),
        status VARCHAR(50) DEFAULT 'Active',
        password VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;

    await pool.query(createPatientsTable);
    console.log('✅ Patients table ready');

    await pool.query(createVitalsTable);
    console.log('✅ Vitals table ready');

    await pool.query(createBedsTable);
    console.log('✅ Beds table ready');

    await pool.query(createAppointmentsTable);
    console.log('✅ Appointments table ready');

    await pool.query(createStaffTable);
    console.log('✅ Staff table ready');

    await pool.query(createStaffTable);
    console.log('✅ Staff table ready');

    const createPrescriptionsTable = `
      CREATE TABLE IF NOT EXISTS prescriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        appointment_id INT NOT NULL,
        image_path VARCHAR(255) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE
      )
    `;

    await pool.query(createPrescriptionsTable);
    console.log('✅ Prescriptions table ready');

    process.exit(0);
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
    process.exit(1);
  }
};

initDb();
