const pool = require('./db');
require('dotenv').config();

const clearData = async () => {
    try {
        console.log('🗑️  Starting data clearance...');

        // Disable foreign key checks to allow truncation
        await pool.query('SET FOREIGN_KEY_CHECKS = 0');

        console.log('... Truncating prescriptions');
        await pool.query('TRUNCATE TABLE prescriptions');

        console.log('... Truncating vitals');
        await pool.query('TRUNCATE TABLE vitals');

        console.log('... Truncating appointments');
        await pool.query('TRUNCATE TABLE appointments');

        console.log('... Truncating beds');
        await pool.query('TRUNCATE TABLE beds');

        console.log('... Truncating patients');
        await pool.query('TRUNCATE TABLE patients');

        console.log('... Truncating staff');
        await pool.query('TRUNCATE TABLE staff');

        // Re-enable foreign key checks
        await pool.query('SET FOREIGN_KEY_CHECKS = 1');

        console.log('✅ All sample data cleared successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Data clearance failed:', error);
        process.exit(1);
    }
};

clearData();
