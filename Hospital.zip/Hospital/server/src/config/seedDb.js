const pool = require('./db');

const seedDb = async () => {
    try {
        console.log('🌱 Starting database seed...');

        // Clear existing data
        await pool.query('SET FOREIGN_KEY_CHECKS = 0');
        await pool.query('TRUNCATE TABLE beds');
        await pool.query('TRUNCATE TABLE vitals');
        await pool.query('TRUNCATE TABLE patients');
        await pool.query('SET FOREIGN_KEY_CHECKS = 1');
        console.log('🧹 Cleared existing data');

        // All sample data insertion logic removed.
        console.log('✨ Database cleared successfully!');
        process.exit(0);

        console.log('✨ Seeding completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('❌ Seeding failed:', error);
        process.exit(1);
    }
};

seedDb();
