const express = require('express');
const router = express.Router();
const pharmacyController = require('../controllers/pharmacy.controller');

// Get all pharmacy prescriptions (with optional status filter)
router.get('/prescriptions', pharmacyController.getPrescriptions);

// Get prescription by ID
router.get('/prescriptions/:id', pharmacyController.getPrescriptionById);

// Mark prescription as dispensed
router.put('/prescriptions/:id/dispense', pharmacyController.dispensePrescription);

// Get pharmacy statistics
router.get('/stats', pharmacyController.getStats);

module.exports = router;
