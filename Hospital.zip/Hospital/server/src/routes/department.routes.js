const express = require('express');
const router = express.Router();
const departmentController = require('../controllers/department.controller');

router.post('/', departmentController.addDepartment);
router.get('/', departmentController.getAllDepartments);
router.put('/:id', departmentController.updateDepartment);

module.exports = router;
