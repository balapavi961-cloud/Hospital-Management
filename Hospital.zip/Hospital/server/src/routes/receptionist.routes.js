const express = require('express');
const router = express.Router();
const receptionistController = require('../controllers/receptionist.controller');

router.get('/patients', receptionistController.getAllPatients);
router.post('/patients', receptionistController.addPatient);

module.exports = router;
