const express = require('express');
const router = express.Router();
const doctorController = require('../controllers/doctor.controller');

router.get('/appointments', doctorController.getAppointments);
router.get('/stats', doctorController.getStats);
router.get('/live-queue', doctorController.getLiveQueue);
router.put('/appointments/:id/status', doctorController.updateStatus);

module.exports = router;
