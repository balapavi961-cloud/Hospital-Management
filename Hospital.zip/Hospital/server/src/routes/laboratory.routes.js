const express = require('express');
const router = express.Router();
const laboratoryController = require('../controllers/laboratory.controller');

// Get all laboratory prescriptions (with optional status filter)
router.get('/prescriptions', laboratoryController.getPrescriptions);

// Get prescription by ID
router.get('/prescriptions/:id', laboratoryController.getPrescriptionById);

// Upload lab report (multiple files supported)
router.post('/prescriptions/:id/upload-report',
    laboratoryController.upload.array('reports', 10), // Allow up to 10 files
    laboratoryController.uploadReport
);

// Send report to doctor
router.put('/prescriptions/:id/send-report', laboratoryController.sendReportToDoctor);

// Get laboratory statistics
router.get('/stats', laboratoryController.getStats);

module.exports = router;
