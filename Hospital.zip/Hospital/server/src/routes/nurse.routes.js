const express = require('express');
const router = express.Router();
const nurseController = require('../controllers/nurse.controller');

router.get('/patients', nurseController.getAssignedPatients);
router.get('/vitals/:patientId', nurseController.getVitals);
router.post('/vitals', nurseController.addVitals);
router.put('/bed/:bedId', nurseController.updateBedStatus);
router.get('/appointments', nurseController.getAppointments);
router.post('/appointments', nurseController.createAppointment);
router.put('/appointments/:id/status', nurseController.updateAppointmentStatus);
router.put('/appointments/:id', nurseController.updateAppointment);

module.exports = router;
