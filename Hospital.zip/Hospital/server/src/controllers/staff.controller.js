const pool = require('../config/db');

// Add new staff
exports.addStaff = async (req, res) => {
    try {
        console.log("Adding Staff:", req.body); // DEBUG
        const {
            name,
            role,
            department,
            age,
            contactNumber, // Mapped from frontend 'contactNumber'
            email,
            place,
            state,
            district,
            thaluk,
            joiningDate,
            shift
        } = req.body;

        await pool.query(
            `INSERT INTO staff (
                name, role, department, age, contact_number, email, 
                place, state, district, thaluk, joining_date, shift_time, password
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                name, role, department, age, contactNumber, email,
                place, state, district, thaluk, joiningDate, shift, req.body.password
            ]
        );

        res.status(201).json({ message: 'Staff added successfully' });
    } catch (error) {
        console.error("Error adding staff:", error);
        res.status(500).json({ message: error.message });
    }
};

// Get all staff
exports.getAllStaff = async (req, res) => {
    try {
        const { role } = req.query;
        let query = 'SELECT * FROM staff ORDER BY created_at DESC';
        let params = [];

        if (role) {
            query = 'SELECT * FROM staff WHERE role = ? ORDER BY created_at DESC';
            params = [role];
        }

        const [rows] = await pool.query(query, params);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update staff
exports.updateStaff = async (req, res) => {
    try {
        const { id } = req.params;
        const {
            name, role, department, age, contactNumber, email,
            place, state, district, thaluk, joiningDate, shift, password
        } = req.body;

        let query = `
            UPDATE staff SET 
            name=?, role=?, department=?, age=?, contact_number=?, email=?, 
            place=?, state=?, district=?, thaluk=?, joining_date=?, shift_time=?
        `;
        let params = [
            name, role, department, age, contactNumber, email,
            place, state, district, thaluk, joiningDate, shift
        ];

        if (password) {
            query += `, password=?`;
            params.push(password);
        }

        query += ` WHERE id=?`;
        params.push(id);

        await pool.query(query, params);

        res.json({ message: 'Staff updated successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Delete staff
exports.deleteStaff = async (req, res) => {
    try {
        const { id } = req.params;
        await pool.query('DELETE FROM staff WHERE id = ?', [id]);
        res.json({ message: 'Staff deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
