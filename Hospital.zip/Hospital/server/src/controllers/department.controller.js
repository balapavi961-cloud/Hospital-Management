const pool = require('../config/db');

// Add Department
exports.addDepartment = async (req, res) => {
    try {
        const { name, head, location, description } = req.body;

        const [result] = await pool.query(
            'INSERT INTO departments (name, head, location, description) VALUES (?, ?, ?, ?)',
            [name, head, location, description]
        );

        res.status(201).json({
            message: 'Department created successfully',
            id: result.insertId
        });
    } catch (error) {
        console.error('Error adding department:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get All Departments
exports.getAllDepartments = async (req, res) => {
    try {
        // Also get staff count for each department
        // Assuming staff table has 'department' column matching name (as per current schema)
        // Ideally IDs should be used, but name is current convention
        const query = `
            SELECT d.*, 
            (SELECT COUNT(*) FROM staff s WHERE s.department = d.name) as staffCount
            FROM departments d
            ORDER BY d.created_at DESC
        `;

        const [rows] = await pool.query(query);
        res.json(rows);
    } catch (error) {
        console.error('Error fetching departments:', error);
        res.status(500).json({ message: error.message });
    }
};
// Update Department
exports.updateDepartment = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, head, location, description } = req.body;

        await pool.query(
            'UPDATE departments SET name=?, head=?, location=?, description=? WHERE id=?',
            [name, head, location, description, id]
        );

        res.json({ message: 'Department updated successfully' });
    } catch (error) {
        console.error('Error updating department:', error);
        res.status(500).json({ message: error.message });
    }
};
