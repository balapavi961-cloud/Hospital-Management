const pool = require('../config/db');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Configure multer for report uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = 'uploads/lab_reports';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, 'report-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
        const allowedTypes = /jpeg|jpg|png|pdf/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);

        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only images and PDF files are allowed'));
        }
    }
});

// Get all laboratory prescriptions
exports.getPrescriptions = async (req, res) => {
    try {
        const { status } = req.query;

        let query = `
            SELECT 
                p.*,
                a.patient_name,
                a.age,
                a.gender,
                a.contact_number,
                a.doctor,
                a.date as appointment_date
            FROM prescriptions p
            LEFT JOIN appointments a ON p.appointment_id = a.id
            WHERE p.prescription_type = 'laboratory'
        `;

        let params = [];

        if (status) {
            query += ' AND p.status = ?';
            params.push(status);
        }

        query += ' ORDER BY p.created_at DESC';

        const [rows] = await pool.query(query, params);
        res.json(rows);
    } catch (error) {
        console.error('Error fetching laboratory prescriptions:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get prescription by ID
exports.getPrescriptionById = async (req, res) => {
    try {
        const { id } = req.params;

        const query = `
            SELECT 
                p.*,
                a.patient_name,
                a.age,
                a.gender,
                a.contact_number,
                a.doctor,
                a.date as appointment_date,
                a.time as appointment_time
            FROM prescriptions p
            LEFT JOIN appointments a ON p.appointment_id = a.id
            WHERE p.id = ? AND p.prescription_type = 'laboratory'
        `;

        const [rows] = await pool.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        res.json(rows[0]);
    } catch (error) {
        console.error('Error fetching prescription:', error);
        res.status(500).json({ message: error.message });
    }
};

// Upload lab report (supports multiple files)
exports.uploadReport = async (req, res) => {
    try {
        const { id } = req.params;
        const { lab_technician } = req.body;

        // Check if files were uploaded (multer array upload)
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ message: 'No files uploaded' });
        }

        // Get all uploaded file paths
        const reportPaths = req.files.map(file => file.path.replace(/\\/g, '/'));

        // Get existing report paths if any
        const [existing] = await pool.query(
            'SELECT report_paths FROM prescriptions WHERE id = ? AND prescription_type = "laboratory"',
            [id]
        );

        if (existing.length === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        // Merge with existing paths - handle null and parse safely
        let allPaths = [];
        if (existing[0].report_paths) {
            try {
                allPaths = JSON.parse(existing[0].report_paths);
                if (!Array.isArray(allPaths)) {
                    allPaths = [];
                }
            } catch (e) {
                // If parsing fails, it's likely a legacy string path
                console.warn('Existing report_paths is not JSON, treating as single path');
                if (typeof existing[0].report_paths === 'string') {
                    allPaths = [existing[0].report_paths];
                } else {
                    allPaths = [];
                }
            }
        }
        allPaths = [...allPaths, ...reportPaths];

        const query = `
            UPDATE prescriptions 
            SET 
                report_paths = ?,
                report_uploaded_at = NOW(),
                lab_technician = ?
            WHERE id = ? AND prescription_type = 'laboratory'
        `;

        const [result] = await pool.query(query, [JSON.stringify(allPaths), lab_technician, id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        res.json({
            message: `${reportPaths.length} report(s) uploaded successfully`,
            report_paths: allPaths
        });
    } catch (error) {
        console.error('Error uploading report:', error);
        res.status(500).json({ message: error.message });
    }
};

// Send report to doctor
exports.sendReportToDoctor = async (req, res) => {
    try {
        const { id } = req.params;

        // Check if report exists
        const [prescription] = await pool.query(
            'SELECT report_paths FROM prescriptions WHERE id = ? AND prescription_type = "laboratory"',
            [id]
        );

        if (prescription.length === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        if (!prescription[0].report_paths) {
            return res.status(400).json({ message: 'No reports uploaded yet' });
        }

        const query = `
            UPDATE prescriptions 
            SET 
                status = 'completed',
                report_sent_at = NOW()
            WHERE id = ? AND prescription_type = 'laboratory'
        `;

        const [result] = await pool.query(query, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        res.json({ message: 'Reports sent to doctor successfully' });
    } catch (error) {
        console.error('Error sending report:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get laboratory statistics
exports.getStats = async (req, res) => {
    try {
        const statsQuery = `
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN DATE(report_sent_at) = CURDATE() THEN 1 ELSE 0 END) as completed_today
            FROM prescriptions
            WHERE prescription_type = 'laboratory'
        `;

        const [stats] = await pool.query(statsQuery);

        res.json(stats[0]);
    } catch (error) {
        console.error('Error fetching laboratory stats:', error);
        res.status(500).json({ message: error.message });
    }
};

exports.upload = upload;
