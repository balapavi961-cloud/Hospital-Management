const pool = require('../config/db');

// Get all pharmacy prescriptions
exports.getPrescriptions = async (req, res) => {
    try {
        const { status } = req.query;

        let query = `
            SELECT 
                p.*,
                a.patient_name,
                a.age,
                a.gender,
                a.contact_number,
                a.doctor,
                a.date as appointment_date
            FROM prescriptions p
            LEFT JOIN appointments a ON p.appointment_id = a.id
            WHERE p.prescription_type = 'pharmacy'
        `;

        let params = [];

        if (status) {
            query += ' AND p.status = ?';
            params.push(status);
        }

        query += ' ORDER BY p.created_at DESC';

        const [rows] = await pool.query(query, params);
        res.json(rows);
    } catch (error) {
        console.error('Error fetching pharmacy prescriptions:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get prescription by ID
exports.getPrescriptionById = async (req, res) => {
    try {
        const { id } = req.params;

        const query = `
            SELECT 
                p.*,
                a.patient_name,
                a.age,
                a.gender,
                a.contact_number,
                a.doctor,
                a.date as appointment_date,
                a.time as appointment_time
            FROM prescriptions p
            LEFT JOIN appointments a ON p.appointment_id = a.id
            WHERE p.id = ? AND p.prescription_type = 'pharmacy'
        `;

        const [rows] = await pool.query(query, [id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        res.json(rows[0]);
    } catch (error) {
        console.error('Error fetching prescription:', error);
        res.status(500).json({ message: error.message });
    }
};

// Mark prescription as dispensed
exports.dispensePrescription = async (req, res) => {
    try {
        const { id } = req.params;
        const { dispensedBy, notes } = req.body;

        const query = `
            UPDATE prescriptions 
            SET 
                status = 'dispensed',
                dispensed_by = ?,
                dispensed_at = NOW(),
                dispensing_notes = ?
            WHERE id = ? AND prescription_type = 'pharmacy'
        `;

        const [result] = await pool.query(query, [dispensedBy, notes, id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Prescription not found' });
        }

        res.json({ message: 'Prescription marked as dispensed successfully' });
    } catch (error) {
        console.error('Error dispensing prescription:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get pharmacy statistics
exports.getStats = async (req, res) => {
    try {
        const statsQuery = `
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'dispensed' THEN 1 ELSE 0 END) as dispensed,
                SUM(CASE WHEN DATE(dispensed_at) = CURDATE() THEN 1 ELSE 0 END) as dispensed_today
            FROM prescriptions
            WHERE prescription_type = 'pharmacy'
        `;

        const [stats] = await pool.query(statsQuery);

        res.json(stats[0]);
    } catch (error) {
        console.error('Error fetching pharmacy stats:', error);
        res.status(500).json({ message: error.message });
    }
};
