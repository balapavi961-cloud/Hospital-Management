const pool = require('../config/db');

// Get appointments for a specific doctor
// Query param: doctorName (optional, if filtering)
exports.getAppointments = async (req, res) => {
    try {
        const { doctorName } = req.query;
        console.log(`Fetching appointments for doctor: ${doctorName || 'All'}`);
        // Modified query to include latest vitals AND join with patients for fallback name/age/gender
        let query = `
            SELECT 
                a.*,
                COALESCE(a.patient_name, p.name) as patient_name,
                COALESCE(a.age, p.age) as age,
                COALESCE(a.gender, p.gender) as gender,
                v.blood_pressure,
                v.heart_rate,
                v.temperature,
                v.oxygen_level,
                v.respiratory_rate,
                v.recorded_at as vitals_recorded_at
            FROM appointments a
            LEFT JOIN patients p ON a.patient_id = p.id
            LEFT JOIN (
                SELECT v1.*
                FROM vitals v1
                INNER JOIN (
                    SELECT patient_id, MAX(recorded_at) as max_date
                    FROM vitals
                    GROUP BY patient_id
                ) v2 ON v1.patient_id = v2.patient_id AND v1.recorded_at = v2.max_date
            ) v ON a.patient_id = v.patient_id
        `;

        let params = [];

        if (doctorName) {
            query += ' WHERE a.doctor = ?';
            params.push(doctorName);
        }

        query += ' ORDER BY a.date ASC, STR_TO_DATE(a.time, \'%h:%i %p\') ASC';

        const [rows] = await pool.query(query, params);

        if (rows.length > 0) {
            console.log("First appointment row:", JSON.stringify(rows[0], null, 2));
        } else {
            console.log("No appointments found.");
        }

        res.json(rows);
    } catch (error) {
        console.error("Error in getAppointments:", error);
        res.status(500).json({ message: error.message });
    }
};

// Get doctor stats
exports.getStats = async (req, res) => {
    try {
        const { doctorName } = req.query;
        let query = 'SELECT status, COUNT(*) as count FROM appointments';
        let params = [];

        if (doctorName) {
            query += ' WHERE doctor = ?';
            params.push(doctorName);
        }

        query += ' GROUP BY status';

        const [rows] = await pool.query(query, params);

        const stats = {
            total: 0,
            upcoming: 0,
            waitingForDoctor: 0,
            completed: 0,
            cancelled: 0
        };

        rows.forEach(row => {
            stats.total += row.count;
            if (row.status === 'upcoming' || row.status === 'scheduled') stats.upcoming += row.count;
            if (row.status === 'in-progress' || row.status === 'waiting') stats.waitingForDoctor += row.count;
            if (row.status === 'completed') stats.completed += row.count;
            if (row.status === 'cancelled') stats.cancelled += row.count;
        });

        res.json(stats);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get live queue (in-progress appointments with vitals)
exports.getLiveQueue = async (req, res) => {
    try {
        const { doctorName } = req.query;

        // Query to get appointments with in-progress status and their latest vitals
        // Using a subquery to get the latest vitals for each patient
        const query = `
            SELECT 
                a.*,
                v.blood_pressure,
                v.heart_rate,
                v.temperature,
                v.oxygen_level,
                v.respiratory_rate,
                v.recorded_at as vitals_recorded_at
            FROM appointments a
            LEFT JOIN (
                SELECT v1.*
                FROM vitals v1
                INNER JOIN (
                    SELECT patient_id, MAX(recorded_at) as max_date
                    FROM vitals
                    GROUP BY patient_id
                ) v2 ON v1.patient_id = v2.patient_id AND v1.recorded_at = v2.max_date
            ) v ON a.patient_id = v.patient_id
            WHERE a.status = 'in-progress' AND a.doctor = ?
            ORDER BY a.time ASC
        `;

        const [rows] = await pool.query(query, [doctorName]);
        res.json(rows);
    } catch (error) {
        console.error("Error fetching live queue:", error);
        res.status(500).json({ message: error.message });
    }
};

// Update Appointment Status
exports.updateStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        await pool.query('UPDATE appointments SET status = ? WHERE id = ?', [status, id]);

        res.json({ message: `Appointment status updated to ${status}` });
    } catch (error) {
        console.error("Error updating appointment status:", error);
        res.status(500).json({ message: error.message });
    }
};
