const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

exports.uploadPrescription = async (req, res) => {
    try {
        const { appointmentId, type, image } = req.body;
        console.log('Upload Prescription Request:', { appointmentId, type, imageType: typeof image, imageLength: image ? image.length : 'N/A' });


        if (!appointmentId || !image) {
            return res.status(400).json({ message: 'Appointment ID and image data are required' });
        }

        // Default type to 'pharmacy' if not provided
        const prescriptionType = type || 'pharmacy';

        // Validating Base64 string (simple check)
        if (typeof image !== 'string') {
            return res.status(400).json({
                message: `Invalid image format. Expected string, got ${typeof image}`,
                receivedType: typeof image,
                // debug info
                preview: JSON.stringify(image).substring(0, 100)
            });
        }

        if (!image.match(/^data:image\/\w+;base64,/)) {
            return res.status(400).json({ message: 'Invalid image format. Must be base64 data URL.' });
        }

        // Extract base64 data
        const base64Data = image.replace(/^data:image\/\w+;base64,/, "");
        const buffer = Buffer.from(base64Data, 'base64');

        // Create directory if not exists
        const uploadDir = path.join(__dirname, '../../uploads/prescriptions');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }

        const fileName = `prescription-${appointmentId}-${prescriptionType}-${Date.now()}.png`;
        const filePath = path.join(uploadDir, fileName);

        // Write file
        fs.writeFileSync(filePath, buffer);

        // Store relative path
        const serverRoot = path.join(__dirname, '../../');
        const relativePath = path.relative(serverRoot, filePath).replace(/\\\\/g, '/');

        const [result] = await pool.query(
            'INSERT INTO prescriptions (appointment_id, image_path, prescription_type, status) VALUES (?, ?, ?, ?)',
            [appointmentId, relativePath, prescriptionType, 'pending']
        );

        res.status(201).json({
            message: 'Prescription uploaded successfully',
            prescriptionId: result.insertId,
            imagePath: relativePath,
            type: prescriptionType
        });

    } catch (error) {
        console.error('Error uploading prescription:', error);
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
};

exports.getPrescription = async (req, res) => {
    try {
        const { appointmentId } = req.params;
        // Fetch all prescriptions, not just one
        const [rows] = await pool.query(
            'SELECT * FROM prescriptions WHERE appointment_id = ? ORDER BY created_at DESC',
            [appointmentId]
        );

        if (rows.length === 0) {
            // Return empty array instead of 404 to handle "no prescriptions" gratefully in frontend
            return res.status(200).json([]);
        }

        res.json(rows);
    } catch (error) {
        console.error('Error fetching prescription:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};

// Send prescription to pharmacy
exports.sendToPharmacy = async (req, res) => {
    try {
        const { id } = req.params;

        await pool.query(
            'UPDATE prescriptions SET sent_to_pharmacy = TRUE, sent_at = NOW() WHERE id = ?',
            [id]
        );

        res.json({ message: 'Prescription sent to pharmacy successfully' });
    } catch (error) {
        console.error('Error sending prescription to pharmacy:', error);
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
};

// Send prescription to lab
exports.sendToLab = async (req, res) => {
    try {
        const { id } = req.params;

        await pool.query(
            'UPDATE prescriptions SET sent_to_lab = TRUE, sent_at = NOW() WHERE id = ?',
            [id]
        );

        res.json({ message: 'Prescription sent to lab successfully' });
    } catch (error) {
        console.error('Error sending prescription to lab:', error);
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
};
