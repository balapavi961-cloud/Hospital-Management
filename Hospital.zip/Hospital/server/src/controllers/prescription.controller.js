const fs = require('fs');
const path = require('path');
const pool = require('../config/db');

exports.uploadPrescription = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ message: 'No file uploaded' });
        }

        const { appointmentId } = req.body;
        if (!appointmentId) {
            // Clean up file if validation fails
            fs.unlinkSync(req.file.path);
            return res.status(400).json({ message: 'Appointment ID is required' });
        }

        // Store path relative to server root for static serving
        // req.file.path might be absolute if uploadDir is absolute
        const serverRoot = path.join(__dirname, '../../');
        const relativePath = path.relative(serverRoot, req.file.path).replace(/\\/g, '/');
        const imagePath = relativePath;

        const [result] = await pool.query(
            'INSERT INTO prescriptions (appointment_id, image_path) VALUES (?, ?)',
            [appointmentId, imagePath]
        );

        res.status(201).json({
            message: 'Prescription uploaded successfully',
            prescriptionId: result.insertId,
            imagePath: imagePath
        });

    } catch (error) {
        console.error('Error uploading prescription:', error);
        // Clean up file on error
        if (req.file) {
            fs.unlinkSync(req.file.path);
        }
        res.status(500).json({ message: 'Internal server error', error: error.message });
    }
};

exports.getPrescription = async (req, res) => {
    try {
        const { appointmentId } = req.params;
        const [rows] = await pool.query(
            'SELECT * FROM prescriptions WHERE appointment_id = ? ORDER BY created_at DESC LIMIT 1',
            [appointmentId]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: 'No prescription found for this appointment' });
        }

        res.json(rows[0]);
    } catch (error) {
        console.error('Error fetching prescription:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
};
