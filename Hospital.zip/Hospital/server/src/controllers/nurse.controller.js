const pool = require('../config/db');

// Get assigned patients for the logged-in nurse
exports.getAssignedPatients = async (req, res) => {
    try {
        // Fetch all patients for now since authentication middleware isn't fully set up with nurse_id
        // In future: const [rows] = await pool.query('SELECT * FROM patients WHERE nurse_id = ?', [req.user.id]); 
        const [rows] = await pool.query('SELECT * FROM patients');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get vitals for a specific patient
exports.getVitals = async (req, res) => {
    try {
        const { patientId } = req.params;
        const [rows] = await pool.query('SELECT * FROM vitals WHERE patient_id = ? ORDER BY recorded_at DESC', [patientId]);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add new vitals
exports.addVitals = async (req, res) => {
    try {
        console.log("Received Vitals Data:", req.body); // DEBUG LOG
        const { patientId, bloodPressure, heartRate, temperature, oxygenLevel, respiratoryRate, height, weight } = req.body;

        if (!patientId) {
            console.error("Missing patientId in request");
            return res.status(400).json({ message: "patientId is required" });
        }

        await pool.query(
            'INSERT INTO vitals (patient_id, blood_pressure, heart_rate, temperature, oxygen_level, respiratory_rate, height, weight) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [patientId, bloodPressure, heartRate, temperature, oxygenLevel, respiratoryRate, height, weight]
        );
        res.status(201).json({ message: 'Vitals recorded successfully' });
    } catch (error) {
        console.error("Error saving vitals:", error);
        console.error("SQL Message:", error.sqlMessage);
        console.error("SQL Code:", error.code);
        res.status(500).json({ message: error.message, sqlError: error.sqlMessage });
    }
};

// Update bed status
exports.updateBedStatus = async (req, res) => {
    try {
        const { bedId } = req.params;
        const { status } = req.body; // e.g., 'occupied', 'available', 'cleaning'
        await pool.query('UPDATE beds SET status = ? WHERE id = ?', [status, bedId]);
        res.json({ message: `Bed status updated to ${status}` });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Get all appointments
exports.getAppointments = async (req, res) => {
    try {
        const query = `
            SELECT a.*, 
            (SELECT COUNT(*) FROM vitals v WHERE v.patient_id = a.patient_id) > 0 AS has_vitals 
            FROM appointments a 
            ORDER BY a.date ASC, STR_TO_DATE(a.time, '%h:%i %p') ASC
        `;
        const [rows] = await pool.query(query);
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Create new appointment
exports.createAppointment = async (req, res) => {
    try {
        console.log("Creating Appointment:", req.body); // DEBUG
        const { patientName, age, gender, contactNumber, doctor, date, time, type, reason } = req.body;

        // 1. Create Patient Record first (or check if exists - for now, simpler to just create)
        // In a real app, we'd check existence by contactNumber or similar.
        const [patientResult] = await pool.query(
            'INSERT INTO patients (name, age, gender, contact_number, diagnosis) VALUES (?, ?, ?, ?, ?)',
            [patientName, age, gender || 'Other', contactNumber, reason || 'General Checkup']
        );
        const patientId = patientResult.insertId;

        // 2. Create Appointment linked to Patient
        await pool.query(
            'INSERT INTO appointments (patient_id, patient_name, age, gender, contact_number, doctor, date, time, type, symptoms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [patientId, patientName, age, gender || 'Other', contactNumber, doctor, date, time, type || 'General Checkup', reason]
        );

        res.status(201).json({ message: 'Appointment booked successfully' });
    } catch (error) {
        console.error("Error creating appointment:", error);
        res.status(500).json({ message: error.message });
    }
};

// Update Appointment Status
exports.updateAppointmentStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        await pool.query('UPDATE appointments SET status = ? WHERE id = ?', [status, id]);

        res.json({ message: `Appointment status updated to ${status}` });
    } catch (error) {
        console.error("Error updating appointment status:", error);
        res.status(500).json({ message: error.message });
    }
};

// Update Appointment Details
exports.updateAppointment = async (req, res) => {
    try {
        const { id } = req.params;
        const { patientName, date, time } = req.body;

        // Update appointment details
        await pool.query(
            'UPDATE appointments SET patient_name = ?, date = ?, time = ? WHERE id = ?',
            [patientName, date, time, id]
        );

        res.json({ message: 'Appointment updated successfully' });
    } catch (error) {
        console.error("Error updating appointment:", error);
        res.status(500).json({ message: error.message });
    }
};
