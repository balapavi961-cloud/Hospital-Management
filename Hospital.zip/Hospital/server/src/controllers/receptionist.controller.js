const pool = require('../config/db');

// Get all patients (with optional search/filtering logic later)
exports.getAllPatients = async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM patients ORDER BY admission_date DESC');
        res.json(rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Add a new patient manually (Log Book)
exports.addPatient = async (req, res) => {
    try {
        const { name, age, gender, contactNumber, reason } = req.body;

        if (!name || !age || !contactNumber) {
            return res.status(400).json({ message: "Name, Age, and Contact Number are required" });
        }

        const [result] = await pool.query(
            'INSERT INTO patients (name, age, gender, contact_number, diagnosis) VALUES (?, ?, ?, ?, ?)',
            [name, age, gender, contactNumber, reason || 'General Visit']
        );

        res.status(201).json({
            message: 'Patient added successfully',
            patientId: result.insertId
        });
    } catch (error) {
        console.error("Error adding patient:", error);
        res.status(500).json({ message: error.message });
    }
};
