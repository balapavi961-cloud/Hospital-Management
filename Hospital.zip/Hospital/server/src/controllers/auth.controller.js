const pool = require('../config/db');

exports.login = async (req, res) => {
    try {
        const { identifier, password, role } = req.body;

        // OPEN LOGIN: Receptionist, Nurse, Institution (Admin)
        // Accepts ANY non-empty credentials
        if (['receptionist', 'nurse', 'institution', 'admin'].includes(role)) {
            // Map 'institution' to 'admin' role for backend consistency
            const dbRole = role === 'institution' ? 'admin' : role;

            return res.json({
                id: 999, // Mock ID
                name: `${dbRole.charAt(0).toUpperCase() + dbRole.slice(1)} User`,
                role: dbRole,
                email: identifier,
                department: 'General'
            });
        }

        // SECURE LOGIN: Doctor and potential others
        // Simple query to match email and password (plain text for prototype)
        const [rows] = await pool.query(
            'SELECT * FROM staff WHERE email = ? AND password = ?',
            [identifier, password]
        );

        if (rows.length === 0) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const user = rows[0];

        // Return user info (excluding password)
        res.json({
            id: user.id,
            name: user.name,
            role: user.role,
            email: user.email,
            department: user.department
        });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
