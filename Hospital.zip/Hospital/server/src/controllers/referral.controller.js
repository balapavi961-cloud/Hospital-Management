const pool = require('../config/db');

// Create a new referral
exports.createReferral = async (req, res) => {
    try {
        const {
            patient_id,
            source_doctor_id,
            source_doctor_name,
            target_doctor_id,
            target_doctor_name,
            target_department_id,
            target_department_name,
            reason
        } = req.body;

        const query = `
            INSERT INTO referrals 
            (patient_id, source_doctor_id, source_doctor_name, target_doctor_id, target_doctor_name, target_department_id, target_department_name, reason) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const [result] = await pool.query(query, [
            patient_id,
            source_doctor_id,
            source_doctor_name,
            target_doctor_id,
            target_doctor_name,
            target_department_id,
            target_department_name,
            reason
        ]);

        res.status(201).json({
            message: 'Referral created successfully',
            referralId: result.insertId
        });
    } catch (error) {
        console.error('Error creating referral:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get referrals for a target doctor
exports.getReferralsForDoctor = async (req, res) => {
    try {
        const { doctorId, doctorName } = req.query;
        let query = 'SELECT * FROM referrals WHERE status != "completed"';
        let params = [];

        // Filter by target doctor (ID or Name)
        if (doctorId) {
            query += ' AND target_doctor_id = ?';
            params.push(doctorId);
        } else if (doctorName) {
            query += ' AND target_doctor_name = ?';
            params.push(doctorName);
        }

        query += ' ORDER BY created_at DESC';

        const [rows] = await pool.query(query, params);
        res.json(rows);
    } catch (error) {
        console.error('Error fetching referrals:', error);
        res.status(500).json({ message: error.message });
    }
};

// Get referrals for a department
exports.getReferralsForDepartment = async (req, res) => {
    try {
        const { departmentId, departmentName } = req.query;
        let query = 'SELECT * FROM referrals WHERE status != "completed"';
        let params = [];

        if (departmentId) {
            query += ' AND target_department_id = ?';
            params.push(departmentId);
        } else if (departmentName) {
            query += ' AND target_department_name = ?';
            params.push(departmentName);
        }

        query += ' ORDER BY created_at DESC';

        const [rows] = await pool.query(query, params);
        res.json(rows);
    } catch (error) {
        console.error('Error fetching department referrals:', error);
        res.status(500).json({ message: error.message });
    }
};

// Update referral status
exports.updateReferralStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body; // e.g., 'accepted', 'completed', 'rejected'

        await pool.query('UPDATE referrals SET status = ? WHERE id = ?', [status, id]);

        res.json({ message: `Referral status updated to ${status}` });
    } catch (error) {
        console.error('Error updating referral status:', error);
        res.status(500).json({ message: error.message });
    }
};
