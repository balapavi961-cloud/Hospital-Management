const axios = require('axios');

const API_URL = 'http://localhost:5000/api/referrals';

const testReferral = async () => {
    try {
        console.log('--- Testing Referral API ---');

        // 1. Create Referral
        const referralData = {
            patient_id: 1, // Ensure patient 1 exists or use valid ID
            source_doctor_id: 101,
            source_doctor_name: 'Dr. Test Source',
            target_doctor_id: 102,
            target_doctor_name: 'Dr. Test Target',
            reason: 'Test referral reason'
        };

        console.log('Creating referral...');
        const createRes = await axios.post(API_URL, referralData);
        console.log('✅ Created:', createRes.data);
        const referralId = createRes.data.referralId;

        // 2. Get Referrals
        console.log('Fetching referrals for Dr. Test Target...');
        const getRes = await axios.get(`${API_URL}/doctor?doctorName=Dr. Test Target`);
        console.log(`✅ Fetched ${getRes.data.length} referrals`);

        const found = getRes.data.find(r => r.id === referralId);
        if (found) {
            console.log('✅ Verified newly created referral exists in list');
        } else {
            console.error('❌ Referral not found in list!');
        }

        // 3. Update Status
        console.log('Updating status...');
        const updateRes = await axios.put(`${API_URL}/${referralId}/status`, { status: 'accepted' });
        console.log('✅ Updated:', updateRes.data);

    } catch (error) {
        console.error('❌ Test Failed:', error.response ? error.response.data : error.message);
    }
};

testReferral();
