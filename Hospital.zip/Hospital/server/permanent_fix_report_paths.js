const pool = require('./src/config/db');

async function permanentlyFixReportPaths() {
    try {
        console.log('Permanently fixing ALL report_paths issues...\n');

        // Step 1: Find and fix any non-JSON report_paths
        const [allPrescriptions] = await pool.query(`
            SELECT id, report_paths 
            FROM prescriptions 
            WHERE prescription_type = 'laboratory' 
            AND report_paths IS NOT NULL
        `);

        console.log(`Checking ${allPrescriptions.length} laboratory prescriptions...\n`);

        let fixed = 0;
        for (const pres of allPrescriptions) {
            try {
                const parsed = JSON.parse(pres.report_paths);
                if (!Array.isArray(parsed)) {
                    throw new Error('Not an array');
                }
                console.log(`  ID ${pres.id}: ✓ Valid JSON array`);
            } catch (e) {
                // Invalid JSON or not an array - fix it
                console.log(`  ID ${pres.id}: ✗ Invalid - Setting to NULL`);
                await pool.query(
                    'UPDATE prescriptions SET report_paths = NULL WHERE id = ?',
                    [pres.id]
                );
                fixed++;
            }
        }

        console.log(`\n✅ Fixed ${fixed} invalid report_paths`);
        console.log(`✓ ${allPrescriptions.length - fixed} were already valid\n`);

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

permanentlyFixReportPaths();
