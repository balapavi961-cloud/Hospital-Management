const pool = require('./src/config/db');

async function checkVitalsJoin() {
    try {
        console.log("Checking appointments and vitals join...");

        let query = `
            SELECT 
                a.id,
                a.patient_name,
                a.patient_id,
                v.blood_pressure,
                v.heart_rate
            FROM appointments a
            LEFT JOIN (
                SELECT v1.*
                FROM vitals v1
                INNER JOIN (
                    SELECT patient_id, MAX(recorded_at) as max_date
                    FROM vitals
                    GROUP BY patient_id
                ) v2 ON v1.patient_id = v2.patient_id AND v1.recorded_at = v2.max_date
            ) v ON a.patient_id = v.patient_id
        `;

        const [rows] = await pool.query(query);
        console.log("Query Results:", JSON.stringify(rows, null, 2));

        // Also check if any vitals exist at all
        const [vitals] = await pool.query('SELECT * FROM vitals LIMIT 5');
        console.log("Sample Vitals:", JSON.stringify(vitals, null, 2));

        // Check appointments
        const [appts] = await pool.query('SELECT * FROM appointments LIMIT 5');
        console.log("Sample Appointments:", JSON.stringify(appts, null, 2));

    } catch (error) {
        console.error("Error:", error);
    } finally {
        process.exit();
    }
}

checkVitalsJoin();
