const pool = require('./src/config/db');

async function checkApptSchema() {
    try {
        const [columns] = await pool.query('DESCRIBE appointments');
        console.log(JSON.stringify(columns, null, 2));
    } catch (error) {
        console.error(error);
    } finally {
        process.exit();
    }
}

checkApptSchema();
