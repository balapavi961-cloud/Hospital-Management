const pool = require('./src/config/db');

async function createLaboratoryUser() {
    try {
        console.log('Creating laboratory user...');

        // Check if laboratory user already exists
        const [existing] = await pool.query(
            'SELECT * FROM staff WHERE email = ?',
            ['lab@hospital.com']
        );

        if (existing.length > 0) {
            console.log('✓ Laboratory user already exists');
            console.log('\n=== Laboratory Login Credentials ===');
            console.log('Email: lab@hospital.com');
            console.log('Password: password123');
            console.log('Role: laboratory');
            console.log('=====================================\n');
            process.exit(0);
        }

        // Insert laboratory user with plain password (for testing only)
        const [result] = await pool.query(`
            INSERT INTO staff (name, role, department, email, password, status, age, contact_number, place, state, district, joining_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            'Lab Technician',
            'laboratory',
            'Laboratory',
            'lab@hospital.com',
            'password123',
            'Active',
            30,
            '9876543210',
            'Hospital Campus',
            'State',
            'District',
            new Date()
        ]);

        console.log('✓ Laboratory user created successfully!');
        console.log('\n=== Laboratory Login Credentials ===');
        console.log('Email: lab@hospital.com');
        console.log('Password: password123');
        console.log('Role: laboratory');
        console.log('=====================================\n');

        process.exit(0);
    } catch (error) {
        console.error('Error creating laboratory user:', error);
        process.exit(1);
    }
}

createLaboratoryUser();
