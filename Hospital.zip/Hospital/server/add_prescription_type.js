const pool = require('./src/config/db');

async function addPrescriptionTypeColumn() {
    try {
        console.log('Adding prescription_type column to prescriptions table...');

        // Check if column exists
        const checkColumn = `
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME = 'prescription_type'
        `;

        const [existingColumns] = await pool.query(checkColumn);

        if (existingColumns.length === 0) {
            // Add prescription_type column
            await pool.query(`
                ALTER TABLE prescriptions 
                ADD COLUMN prescription_type VARCHAR(20) DEFAULT 'pharmacy'
            `);
            console.log('✓ Added prescription_type column');

            // Update existing records
            await pool.query(`
                UPDATE prescriptions 
                SET prescription_type = 'pharmacy' 
                WHERE prescription_type IS NULL
            `);
            console.log('✓ Updated existing prescriptions with default type');
        } else {
            console.log('✓ prescription_type column already exists');
        }

        console.log('Prescription type column setup completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('Error adding prescription_type column:', error);
        process.exit(1);
    }
}

addPrescriptionTypeColumn();
