const pool = require('./src/config/db');

async function addLabReportColumns() {
    try {
        console.log('Adding laboratory report columns to prescriptions table...');

        // Check if columns already exist
        const [columns] = await pool.query(`
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME IN ('report_path', 'report_uploaded_at', 'report_sent_at', 'lab_technician')
        `);

        if (columns.length === 0) {
            // Add columns for lab reports
            await pool.query(`
                ALTER TABLE prescriptions
                ADD COLUMN report_path VARCHAR(255) DEFAULT NULL,
                ADD COLUMN report_uploaded_at DATETIME DEFAULT NULL,
                ADD COLUMN report_sent_at DATETIME DEFAULT NULL,
                ADD COLUMN lab_technician VARCHAR(255) DEFAULT NULL
            `);
            console.log('✓ Added laboratory report columns');
        } else {
            console.log('✓ Laboratory report columns already exist');
        }

        console.log('Migration completed successfully!');
        process.exit(0);
    } catch (error) {
        console.error('Error adding laboratory report columns:', error);
        process.exit(1);
    }
}

addLabReportColumns();
