const pool = require('./src/config/db');
const fs = require('fs');
const path = require('path');

const checkPrescriptions = async () => {
    try {
        const [rows] = await pool.query("SELECT * FROM prescriptions ORDER BY id DESC LIMIT 5");
        let output = '--- Recent Prescriptions in DB ---\n';
        output += JSON.stringify(rows, null, 2);

        const uploadDir = path.join(__dirname, 'uploads/prescriptions');
        if (fs.existsSync(uploadDir)) {
            const files = fs.readdirSync(uploadDir);
            output += '\n\n--- Files in server/uploads/prescriptions ---\n';
            output += JSON.stringify(files, null, 2);
        } else {
            output += '\n\n--- Directory server/uploads/prescriptions does NOT exist ---';
        }

        fs.writeFileSync('debug_output.txt', output);
        process.exit(0);
    } catch (err) {
        fs.writeFileSync('debug_output.txt', 'Error: ' + err.message);
        process.exit(1);
    }
};

checkPrescriptions();
