const pool = require('./src/config/db');

const addHeightWeight = async () => {
    try {
        console.log('Adding height and weight columns to vitals table...');

        // Add height column
        try {
            await pool.query('ALTER TABLE vitals ADD COLUMN height DECIMAL(5,2) AFTER respiratory_rate');
            console.log('✅ Added height column');
        } catch (err) {
            if (err.code === 'ER_DUP_FIELDNAME') {
                console.log('⚠️ Height column already exists');
            } else {
                throw err;
            }
        }

        // Add weight column
        try {
            await pool.query('ALTER TABLE vitals ADD COLUMN weight DECIMAL(5,2) AFTER height');
            console.log('✅ Added weight column');
        } catch (err) {
            if (err.code === 'ER_DUP_FIELDNAME') {
                console.log('⚠️ Weight column already exists');
            } else {
                throw err;
            }
        }

        console.log('🎉 Migration completed successfully');
        process.exit(0);
    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    }
};

addHeightWeight();
