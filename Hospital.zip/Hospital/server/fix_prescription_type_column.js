const pool = require('./src/config/db');

async function fixPrescriptionsTable() {
    try {
        // Check current schema
        const [columns] = await pool.query(`
            SELECT COLUMN_NAME, COLUMN_TYPE, CHARACTER_MAXIMUM_LENGTH 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'hospital_management' 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME = 'type'
        `);

        console.log('Current type column schema:', columns);

        // Alter the column to VARCHAR(50) to handle multi-page types like 'pharmacy-page1', 'laboratory-page2'
        await pool.query(`
            ALTER TABLE prescriptions 
            MODIFY COLUMN type VARCHAR(50) NOT NULL DEFAULT 'pharmacy'
        `);

        console.log('✅ Successfully updated prescriptions.type column to VARCHAR(50)');

        // Verify the change
        const [updatedColumns] = await pool.query(`
            SELECT COLUMN_NAME, COLUMN_TYPE, CHARACTER_MAXIMUM_LENGTH 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_SCHEMA = 'hospital_management' 
            AND TABLE_NAME = 'prescriptions'
            AND COLUMN_NAME = 'type'
        `);

        console.log('Updated type column schema:', updatedColumns);

        process.exit(0);
    } catch (error) {
        console.error('Error fixing prescriptions table:', error);
        process.exit(1);
    }
}

fixPrescriptionsTable();
