const pool = require('./src/config/db');

const checkStaff = async () => {
    try {
        const [rows] = await pool.query('SELECT role, email, password, name, department FROM staff');
        console.log('--- USERS START ---');
        if (rows.length === 0) {
            console.log('No staff found.');
        } else {
            rows.forEach(u => {
                console.log(`[${u.role}] ${u.name} (${u.department || 'No Dept'}): ${u.email} / ${u.password}`);
            });
        }
        console.log('--- USERS END ---');
        process.exit(0);
    } catch (error) {
        console.error(error);
        process.exit(1);
    }
};

checkStaff();
