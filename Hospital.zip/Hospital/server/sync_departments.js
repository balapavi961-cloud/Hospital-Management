const pool = require('./src/config/db');

const syncDepartments = async () => {
    try {
        const hardcodedDepts = [
            'General Medicine',
            'Cardiology',
            'Orthopedics',
            'Pediatrics',
            'Neurology',
            'Administration',
            'Nursing',
            'Laboratory',
            'Pharmacy'
        ];

        console.log('Syncing departments...');

        for (const dept of hardcodedDepts) {
            // Check if exists
            const [rows] = await pool.query('SELECT id FROM departments WHERE name = ?', [dept]);

            if (rows.length === 0) {
                await pool.query(
                    'INSERT INTO departments (name, description) VALUES (?, ?)',
                    [dept, 'Imported from system defaults']
                );
                console.log(`✅ Added: ${dept}`);
            } else {
                console.log(`ℹ️ Exists: ${dept}`);
            }
        }

        console.log('Department sync complete.');
        process.exit(0);
    } catch (error) {
        console.error(error);
        process.exit(1);
    }
};

syncDepartments();
