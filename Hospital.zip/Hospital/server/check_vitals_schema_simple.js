const pool = require('./src/config/db');

const checkSchema = async () => {
    try {
        const [columns] = await pool.query("SHOW COLUMNS FROM vitals");
        console.log('--- Vitals Columns ---');
        columns.forEach(c => console.log(c.Field));
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

checkSchema();
