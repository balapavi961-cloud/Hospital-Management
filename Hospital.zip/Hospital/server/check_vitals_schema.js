const pool = require('./src/config/db');

const checkSchema = async () => {
    try {
        const [columns] = await pool.query("DESCRIBE vitals");
        console.log('--- Vitals Table Schema ---');
        console.log(columns.map(c => `${c.Field} (${c.Type})`));
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

checkSchema();
