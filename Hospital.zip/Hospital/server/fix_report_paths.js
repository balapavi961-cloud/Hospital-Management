const pool = require('./src/config/db');

async function fixAllReportPaths() {
    try {
        console.log('Fixing ALL report_paths in database...\n');

        // Update ALL prescriptions - set report_paths to NULL if it's not valid JSON
        await pool.query(`
            UPDATE prescriptions 
            SET report_paths = NULL 
            WHERE prescription_type = 'laboratory' 
            AND report_paths IS NOT NULL 
            AND report_paths NOT LIKE '[%'
        `);

        console.log('✅ Cleared all invalid report_paths');
        console.log('Lab prescriptions can now accept new uploads without errors.\n');

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

fixAllReportPaths();
