const pool = require('./src/config/db');

async function seedVitals() {
    try {
        console.log("🌱 Seeding vitals for existing appointments...");

        // Get all patients who have appointments but no vitals (or just add recent vitals for all)
        // For simplicity, let's add vitals for ALL patients who have appointments today/upcoming

        const [patients] = await pool.query(`
            SELECT DISTINCT patient_id, patient_name 
            FROM appointments 
            WHERE patient_id IS NOT NULL
        `);

        if (patients.length === 0) {
            console.log("No appointments found to seed vitals for.");
            return;
        }

        console.log(`Found ${patients.length} patients with appointments.`);

        for (const p of patients) {
            console.log(`Adding vitals for ${p.patient_name} (ID: ${p.patient_id})...`);

            await pool.query(`
                INSERT INTO vitals 
                (patient_id, blood_pressure, heart_rate, temperature, oxygen_level, respiratory_rate, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            `, [p.patient_id, '120/80', '72 bpm', '98.6°F', '98%', '16/min']);
        }

        console.log("✅ Successfully seeded vitals!");

    } catch (error) {
        console.error("Error seeding vitals:", error);
    } finally {
        process.exit();
    }
}

seedVitals();
