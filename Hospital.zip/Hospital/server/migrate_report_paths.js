const pool = require('./src/config/db');

async function migrateOldReportPaths() {
    try {
        console.log('Migrating old report_paths data...\n');

        // Find all prescriptions with report_paths that are not valid JSON arrays
        const [prescriptions] = await pool.query(`
            SELECT id, report_paths 
            FROM prescriptions 
            WHERE report_paths IS NOT NULL 
            AND prescription_type = 'laboratory'
        `);

        console.log(`Found ${prescriptions.length} prescriptions with report_paths`);

        let migrated = 0;
        for (const pres of prescriptions) {
            try {
                // Try to parse as JSON
                const parsed = JSON.parse(pres.report_paths);
                if (Array.isArray(parsed)) {
                    console.log(`  ID ${pres.id}: Already valid JSON array ✓`);
                    continue;
                }
            } catch (e) {
                // Not valid JSON, it's a plain string - convert to array
                const singlePath = pres.report_paths;
                const arrayPath = JSON.stringify([singlePath]);

                await pool.query(
                    'UPDATE prescriptions SET report_paths = ? WHERE id = ?',
                    [arrayPath, pres.id]
                );

                console.log(`  ID ${pres.id}: Migrated "${singlePath}" to JSON array ✓`);
                migrated++;
            }
        }

        console.log(`\n✅ Migration complete!`);
        console.log(`   Total: ${prescriptions.length}`);
        console.log(`   Migrated: ${migrated}`);
        console.log(`   Already valid: ${prescriptions.length - migrated}\n`);

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

migrateOldReportPaths();
