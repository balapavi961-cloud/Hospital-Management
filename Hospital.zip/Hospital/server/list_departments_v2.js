const pool = require('./src/config/db');

const listDepartments = async () => {
    try {
        const [rows] = await pool.query('SELECT * FROM departments ORDER BY name');
        console.log(`Total Departments: ${rows.length}`);
        console.table(rows.map(d => ({ Name: d.name })));
        process.exit(0);
    } catch (error) {
        console.error(error);
        process.exit(1);
    }
};

listDepartments();
