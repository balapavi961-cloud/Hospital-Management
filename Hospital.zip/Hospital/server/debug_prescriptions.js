const pool = require('./src/config/db');
const fs = require('fs');
const path = require('path');

const checkPrescriptions = async () => {
    try {
        const [rows] = await pool.query("SELECT * FROM prescriptions ORDER BY id DESC LIMIT 5");
        console.log('--- Recent Prescriptions in DB ---');
        console.log(rows);

        const uploadDir = path.join(__dirname, 'uploads/prescriptions');
        if (fs.existsSync(uploadDir)) {
            const files = fs.readdirSync(uploadDir);
            console.log('\n--- Files in server/uploads/prescriptions ---');
            console.log(files);
        } else {
            console.log('\n--- Directory server/uploads/prescriptions does NOT exist ---');
        }

        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

checkPrescriptions();
