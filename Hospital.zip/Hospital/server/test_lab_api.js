const axios = require('axios');

async function testLabAPI() {
    try {
        console.log('Testing Laboratory API endpoints...\n');

        // Test 1: Get all prescriptions
        console.log('1. Testing GET /api/laboratory/prescriptions');
        const response1 = await axios.get('http://localhost:5000/api/laboratory/prescriptions');
        console.log(`   Status: ${response1.status}`);
        console.log(`   Found ${response1.data.length} prescription(s)`);
        console.log(`   Data:`, JSON.stringify(response1.data, null, 2));
        console.log('');

        // Test 2: Get stats
        console.log('2. Testing GET /api/laboratory/stats');
        const response2 = await axios.get('http://localhost:5000/api/laboratory/stats');
        console.log(`   Status: ${response2.status}`);
        console.log(`   Stats:`, JSON.stringify(response2.data, null, 2));
        console.log('');

        console.log('✓ All API tests passed!');
        process.exit(0);
    } catch (error) {
        console.error('✗ API Error:', error.message);
        if (error.response) {
            console.error('Response status:', error.response.status);
            console.error('Response data:', error.response.data);
        }
        process.exit(1);
    }
}

testLabAPI();
