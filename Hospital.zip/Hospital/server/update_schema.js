const pool = require('./src/config/db');

async function updateSchema() {
    try {
        console.log("🛠 Updating vitals table schema...");

        // Alter columns to VARCHAR to support "120/80", "98%", etc.
        await pool.query('ALTER TABLE vitals MODIFY blood_pressure VARCHAR(50)');
        await pool.query('ALTER TABLE vitals MODIFY heart_rate VARCHAR(50)');
        await pool.query('ALTER TABLE vitals MODIFY temperature VARCHAR(50)');
        await pool.query('ALTER TABLE vitals MODIFY oxygen_level VARCHAR(50)');
        await pool.query('ALTER TABLE vitals MODIFY respiratory_rate VARCHAR(50)');

        console.log("✅ Schema updated successfully!");

    } catch (error) {
        console.error("Error updating schema:", error);
    } finally {
        process.exit();
    }
}

updateSchema();
