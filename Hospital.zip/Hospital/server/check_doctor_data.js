const pool = require('./src/config/db');

const checkData = async () => {
    try {
        const [staff] = await pool.query("SELECT * FROM staff WHERE role = 'Doctor'");
        console.log('--- Doctors in DB ---');
        console.log(staff);

        const [appointments] = await pool.query("SELECT id, patient_name, doctor, status FROM appointments");
        console.log('\n--- Appointments ---');
        console.log(appointments);

        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

checkData();
