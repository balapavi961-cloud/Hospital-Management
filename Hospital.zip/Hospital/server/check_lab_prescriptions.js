const pool = require('./src/config/db');

async function checkLabPrescriptions() {
    try {
        console.log('Checking laboratory prescriptions in database...\n');

        const [rows] = await pool.query(`
            SELECT 
                p.*,
                a.patient_name,
                a.age,
                a.gender,
                a.doctor,
                a.date as appointment_date
            FROM prescriptions p
            LEFT JOIN appointments a ON p.appointment_id = a.id
            WHERE p.prescription_type = 'laboratory'
            ORDER BY p.created_at DESC
        `);

        console.log(`Found ${rows.length} laboratory prescription(s):\n`);

        rows.forEach((row, index) => {
            console.log(`--- Prescription ${index + 1} ---`);
            console.log(`ID: ${row.id}`);
            console.log(`Patient: ${row.patient_name}`);
            console.log(`Age: ${row.age}, Gender: ${row.gender}`);
            console.log(`Doctor: ${row.doctor}`);
            console.log(`Status: ${row.status}`);
            console.log(`Type: ${row.prescription_type}`);
            console.log(`Created: ${row.created_at}`);
            console.log(`Image Path: ${row.image_path}`);
            console.log(`Report Path: ${row.report_path || 'Not uploaded yet'}`);
            console.log('');
        });

        if (rows.length === 0) {
            console.log('No laboratory prescriptions found!');
            console.log('This might be why the lab portal is empty.');
        }

        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

checkLabPrescriptions();
