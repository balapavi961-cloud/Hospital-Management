const pool = require('./src/config/db');

const fixPaths = async () => {
    try {
        const [rows] = await pool.query("SELECT id, image_path FROM prescriptions");
        console.log(`Found ${rows.length} prescriptions.`);

        for (const row of rows) {
            if (row.image_path.includes('Users')) { // Detect absolute path (Windows)
                // Extract part after 'server/'
                // Assuming standard path structure: .../Hospital/server/uploads/...
                const uploadsIndex = row.image_path.indexOf('uploads/');
                if (uploadsIndex !== -1) {
                    const newPath = row.image_path.substring(uploadsIndex);
                    console.log(`Fixing ID ${row.id}: ${row.image_path} -> ${newPath}`);

                    await pool.query('UPDATE prescriptions SET image_path = ? WHERE id = ?', [newPath, row.id]);
                }
            }
        }

        console.log('Migration complete.');
        process.exit(0);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
};

fixPaths();
