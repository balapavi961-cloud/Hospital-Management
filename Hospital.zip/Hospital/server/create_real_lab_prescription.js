const fs = require('fs');
const path = require('path');
const pool = require('./src/config/db');

async function createRealLabPrescription() {
    try {
        console.log('Creating lab prescription with actual image file...\n');

        // Create uploads directory if it doesn't exist
        const uploadDir = path.join(__dirname, 'uploads/prescriptions');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
            console.log('✓ Created uploads/prescriptions directory');
        }

        // Create a simple test image (1x1 pixel PNG)
        const testImageBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
        const imageBuffer = Buffer.from(testImageBase64, 'base64');

        const fileName = `prescription-test-lab-${Date.now()}.png`;
        const filePath = path.join(uploadDir, fileName);

        // Write the file
        fs.writeFileSync(filePath, imageBuffer);
        console.log(`✓ Created test image: ${fileName}`);

        // Get or create appointment
        let appointmentId;
        const [appointments] = await pool.query('SELECT id FROM appointments LIMIT 1');

        if (appointments.length === 0) {
            await pool.query(`
                INSERT INTO appointments (patient_name, age, gender, contact_number, doctor, date, time, type, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, ['Test Patient', 30, 'Male', '1234567890', 'Dr. Test', '2026-01-22', '12:00 PM', 'Lab Test', 'in-progress']);

            const [newAppt] = await pool.query('SELECT LAST_INSERT_ID() as id');
            appointmentId = newAppt[0].id;
        } else {
            appointmentId = appointments[0].id;
        }

        // Insert prescription with correct path
        const relativePath = `uploads/prescriptions/${fileName}`;
        const [result] = await pool.query(`
            INSERT INTO prescriptions (appointment_id, image_path, prescription_type, status, created_at)
            VALUES (?, ?, ?, ?, NOW())
        `, [appointmentId, relativePath, 'laboratory', 'pending']);

        console.log('\n✅ Lab prescription created successfully!');
        console.log(`  Prescription ID: ${result.insertId}`);
        console.log(`  Image path: ${relativePath}`);
        console.log(`  File exists: ${fs.existsSync(filePath)}`);
        console.log(`\n🌐 Image URL: http://localhost:5000/${relativePath}`);
        console.log(`\n📱 View in lab portal: http://localhost:5173/dashboard/laboratory/prescriptions\n`);

        process.exit(0);
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

createRealLabPrescription();
