const pool = require('./src/config/db');

async function checkData() {
    try {
        console.log("🔍 Checking Appointments Data...");
        const [rows] = await pool.query(`
            SELECT id, patient_name, age, gender, doctor, status 
            FROM appointments 
            ORDER BY id DESC 
            LIMIT 5
        `);
        console.log(JSON.stringify(rows, null, 2));

        console.log("\n🔍 Checking Joined Data (Simulation of Controller)...");
        const [joined] = await pool.query(`
             SELECT 
                a.id,
                COALESCE(a.patient_name, p.name) as patient_name,
                COALESCE(a.age, p.age) as age,
                COALESCE(a.gender, p.gender) as gender
            FROM appointments a
            LEFT JOIN patients p ON a.patient_id = p.id
            ORDER BY a.id DESC 
            LIMIT 5
        `);
        console.log(JSON.stringify(joined, null, 2));

    } catch (error) {
        console.error(error);
    } finally {
        process.exit();
    }
}

checkData();
