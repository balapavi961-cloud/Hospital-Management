const pool = require('./src/config/db');

async function addMultipleReportsSupport() {
    try {
        console.log('Adding support for multiple lab reports...\n');

        // Check if report_paths column exists
        const [columns] = await pool.query(`
            SELECT COLUMN_NAME 
            FROM INFORMATION_SCHEMA.COLUMNS 
            WHERE TABLE_NAME = 'prescriptions' 
            AND COLUMN_NAME = 'report_paths'
        `);

        if (columns.length === 0) {
            console.log('Adding report_paths column...');

            // Add new column for multiple report paths (JSON array)
            await pool.query(`
                ALTER TABLE prescriptions 
                ADD COLUMN report_paths JSON DEFAULT NULL AFTER report_path
            `);

            console.log('✓ Added report_paths column');

            // Migrate existing single report_path to report_paths array
            await pool.query(`
                UPDATE prescriptions 
                SET report_paths = JSON_ARRAY(report_path)
                WHERE report_path IS NOT NULL AND report_paths IS NULL
            `);

            console.log('✓ Migrated existing report paths to array format');
        } else {
            console.log('✓ report_paths column already exists');
        }

        console.log('\n✅ Database updated successfully!');
        console.log('Prescriptions table now supports multiple lab report files.\n');

        process.exit(0);
    } catch (error) {
        console.error('❌ Error:', error);
        process.exit(1);
    }
}

addMultipleReportsSupport();
