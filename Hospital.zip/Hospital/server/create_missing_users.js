const pool = require('./src/config/db');

const createStaff = async () => {
    try {
        console.log('Creating staff...');

        // Admin
        await pool.query(`INSERT INTO staff (name, role, department, email, password, status) VALUES (?, ?, ?, ?, ?, ?)`,
            ['Admin User', 'admin', 'Management', 'admin@hospital.com', 'Admin@123', 'Active']);
        console.log('Admin created.');

        // Receptionist
        await pool.query(`INSERT INTO staff (name, role, department, email, password, status) VALUES (?, ?, ?, ?, ?, ?)`,
            ['Receptionist User', 'receptionist', 'Front Desk', 'receptionist@hospital.com', 'Receptionist@123', 'Active']);
        console.log('Receptionist created.');

        // Nurse
        await pool.query(`INSERT INTO staff (name, role, department, email, password, status) VALUES (?, ?, ?, ?, ?, ?)`,
            ['Nurse User', 'nurse', 'Nursing', 'nurse@hospital.com', 'Nurse@123', 'Active']);
        console.log('Nurse created.');

        // Laboratory
        await pool.query(`INSERT INTO staff (name, role, department, email, password, status) VALUES (?, ?, ?, ?, ?, ?)`,
            ['Lab User', 'laboratory', 'Pathology', 'lab@hospital.com', 'Lab@123', 'Active']);
        console.log('Lab created.');

        // Pharmacy
        await pool.query(`INSERT INTO staff (name, role, department, email, password, status) VALUES (?, ?, ?, ?, ?, ?)`,
            ['Pharmacy User', 'pharmacy', 'Pharmacy', 'pharmacy@hospital.com', 'Pharmacy@123', 'Active']);
        console.log('Pharmacy created.');

        console.log('All missing staff created successfully.');
        process.exit(0);
    } catch (error) {
        // Ignore duplicate entry errors if they exist, but log others
        if (error.code === 'ER_DUP_ENTRY') {
            console.log('Some users likely already exist (Duplicate entry).');
            process.exit(0);
        }
        console.error(error);
        process.exit(1);
    }
};

createStaff();
