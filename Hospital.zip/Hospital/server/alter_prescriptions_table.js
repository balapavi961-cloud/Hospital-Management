const pool = require('./src/config/db');

async function alterTable() {
    try {
        console.log('Altering prescriptions table...');

        // Add type column if it doesn't exist
        // We use a safe approach: try to add it, if it fails it might already exist (or we check first)
        // Simple way: Try ADD COLUMN. If error, check if it's "duplicate column name".

        try {
            await pool.query(`
                ALTER TABLE prescriptions 
                ADD COLUMN type ENUM('pharmacy', 'laboratory') NOT NULL DEFAULT 'pharmacy' AFTER appointment_id
            `);
            console.log('Successfully added type column.');
        } catch (err) {
            if (err.code === 'ER_DUP_FIELDNAME') {
                console.log('Column type already exists.');
            } else {
                throw err;
            }
        }

        console.log('Table alteration complete.');
        process.exit(0);
    } catch (error) {
        console.error('Error altering table:', error);
        process.exit(1);
    }
}

alterTable();
