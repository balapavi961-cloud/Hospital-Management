const pool = require('./src/config/db');

async function clearSampleData() {
    try {
        console.log('🗑️  Clearing all sample data from the database...\n');

        // Clear prescriptions first (has foreign keys)
        console.log('Clearing prescriptions...');
        const [prescriptions] = await pool.query('DELETE FROM prescriptions');
        console.log(`✓ Deleted ${prescriptions.affectedRows} prescription(s)`);

        // Clear appointments
        console.log('Clearing appointments...');
        const [appointments] = await pool.query('DELETE FROM appointments');
        console.log(`✓ Deleted ${appointments.affectedRows} appointment(s)`);

        // Clear referrals
        console.log('Clearing referrals...');
        const [referrals] = await pool.query('DELETE FROM referrals');
        console.log(`✓ Deleted ${referrals.affectedRows} referral(s)`);

        // Clear staff (doctors, nurses, etc.) - optional, comment out if you want to keep staff
        console.log('Clearing staff...');
        const [staff] = await pool.query('DELETE FROM staff');
        console.log(`✓ Deleted ${staff.affectedRows} staff member(s)`);

        // Reset auto-increment IDs
        console.log('\nResetting auto-increment IDs...');
        await pool.query('ALTER TABLE prescriptions AUTO_INCREMENT = 1');
        await pool.query('ALTER TABLE appointments AUTO_INCREMENT = 1');
        await pool.query('ALTER TABLE referrals AUTO_INCREMENT = 1');
        await pool.query('ALTER TABLE staff AUTO_INCREMENT = 1');
        console.log('✓ Auto-increment IDs reset');

        console.log('\n✅ All sample data has been cleared!');
        console.log('You can now add real data to your system.\n');

        process.exit(0);
    } catch (error) {
        console.error('❌ Error clearing data:', error);
        process.exit(1);
    }
}

clearSampleData();
