import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { User, Lock, ArrowRight, HeartPulse, Activity, Stethoscope, Building2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { roleConfig } from '../config/roles';
import FloatingInput from '../components/ui/FloatingInput';

const Login = () => {
    const { role } = useParams();
    const navigate = useNavigate();
    const currentRole = role || 'patient';
    const config = roleConfig[currentRole];

    // Form State
    const [formData, setFormData] = useState({ identifier: '', password: '' });
    const [errors, setErrors] = useState({});
    const [isLoading, setIsLoading] = useState(false);

    const validate = () => {
        const newErrors = {};
        if (!formData.identifier) newErrors.identifier = 'ID is required';
        if (!formData.password) newErrors.password = 'Password is required';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        setIsLoading(true);
        try {
            const response = await fetch('http://localhost:5000/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ ...formData, role: currentRole })
            });

            const data = await response.json();

            if (!response.ok) {
                setErrors({ form: data.message || 'Login failed' });
                setIsLoading(false);
                return;
            }

            // Save user info
            localStorage.setItem('user', JSON.stringify(data));
            localStorage.setItem('role', currentRole); // Ensure role matches

            // Redirect
            navigate(config.route || `/dashboard/${currentRole}`);
        } catch (error) {
            console.error('Login error:', error);
            setErrors({ form: 'Connection error. Please try again.' });
            setIsLoading(false);
        }

    };

    return (
        <div className="min-h-screen w-full flex bg-slate-50 overflow-hidden">
            {/* LEFT SIDE: Portal Selection */}
            <div className="hidden md:flex w-1/3 min-w-[320px] bg-slate-900 text-white flex-col relative overflow-hidden p-8">
                {/* Background Decor */}
                <div className="absolute top-0 left-0 w-full h-full opacity-20 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-teal-500 via-emerald-600 to-slate-900" />
                <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-emerald-500 rounded-full blur-[100px] opacity-20" />

                {/* Branding */}
                <div className="relative z-10 mb-12 flex items-center gap-3">
                    <div className="p-2 bg-emerald-600 rounded-lg">
                        <Building2 size={24} className="text-white" />
                    </div>
                    <div>
                        <h1 className="text-xl font-bold tracking-tight">MediCare<span className="text-emerald-400">Plus</span></h1>
                        <p className="text-xs text-slate-400">Hospital Management System</p>
                    </div>
                </div>

                {/* Portal List */}
                <div className="relative z-10 flex-1 space-y-4">
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-6">Select Portal</p>

                    {Object.entries(roleConfig).map(([key, value]) => {
                        const ItemIcon = value.icon;
                        const isActive = key === currentRole;
                        return (
                            <button
                                key={key}
                                onClick={() => navigate(`/login/${key}`)}
                                className={`
                                    w-full p-4 rounded-xl flex items-center gap-4 transition-all duration-300 border
                                    ${isActive
                                        ? 'bg-emerald-600 border-emerald-500 shadow-lg shadow-emerald-900/50 translate-x-2'
                                        : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/10'}
                                `}
                            >
                                <div className={`p-2 rounded-lg ${isActive ? 'bg-white/20' : 'bg-slate-800'}`}>
                                    <ItemIcon size={20} className={isActive ? 'text-white' : 'text-slate-400'} />
                                </div>
                                <div className="text-left">
                                    <h3 className={`font-semibold ${isActive ? 'text-white' : 'text-slate-300'}`}>
                                        {value.title.split(' ')[0]} {/* Just "Patient", "Nurse", etc */}
                                    </h3>
                                    <p className={`text-xs ${isActive ? 'text-emerald-100' : 'text-slate-500'}`}>
                                        {value.description.slice(0, 30)}...
                                    </p>
                                </div>
                                {isActive && <ArrowRight size={16} className="ml-auto text-emerald-200" />}
                            </button>
                        );
                    })}
                </div>

                {/* Footer Info */}
                <div className="relative z-10 mt-auto pt-8 border-t border-white/10">
                    <div className="flex items-center gap-2 text-slate-400 text-sm">
                        <Activity size={16} className="text-emerald-500" />
                        <span>System Operational</span>
                    </div>
                </div>
            </div>

            {/* RIGHT SIDE: Login Form */}
            <div className="flex-1 flex items-center justify-center p-4 md:p-8 relative bg-white md:bg-slate-50">
                {/* Mobile Header (visible only on small screens) */}
                <div className="absolute top-6 left-6 md:hidden flex items-center gap-2 text-slate-800">
                    <Building2 size={24} className="text-emerald-600" />
                    <span className="font-bold">MediCare+</span>
                </div>

                <motion.div
                    key={currentRole}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4 }}
                    className="w-full max-w-md bg-white md:shadow-xl md:rounded-2xl p-8 md:p-12 border-slate-100"
                >
                    <div className="mb-10">
                        <div className={`inline-flex p-3 rounded-2xl bg-gradient-to-br ${config.color} mb-6 shadow-lg transform -translate-y-2`}>
                            <config.icon size={32} className="text-white" />
                        </div>
                        <h2 className="text-3xl font-bold text-slate-800 mb-2">{config.title}</h2>
                        <p className="text-slate-500">{config.description}</p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <FloatingInput
                            id="identifier"
                            label="Email or ID"
                            icon={User}
                            value={formData.identifier}
                            onChange={(e) => setFormData({ ...formData, identifier: e.target.value })}
                            error={errors.identifier}
                            // Override styles for light theme
                            className="text-slate-800 bg-slate-50 border-slate-200 focus:border-emerald-500"
                        />

                        <FloatingInput
                            id="password"
                            type="password"
                            label="Password"
                            icon={Lock}
                            value={formData.password}
                            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                            error={errors.password}
                            className="text-slate-800 bg-slate-50 border-slate-200 focus:border-emerald-500"
                        />

                        {errors.form && (
                            <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg text-center font-medium">
                                {errors.form}
                            </div>
                        )}

                        <div className="flex items-center justify-between">
                            <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                                <input type="checkbox" className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500" />
                                <span>Remember me</span>
                            </label>
                            <button type="button" className="text-sm font-semibold text-emerald-600 hover:text-emerald-700">
                                Forgot Password?
                            </button>
                        </div>

                        <button
                            type="submit"
                            className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold shadow-lg shadow-slate-900/20 transition-all flex items-center justify-center gap-2"
                        >
                            {isLoading ? 'Signing In...' : 'Access Portal'}
                            {!isLoading && <ArrowRight size={18} />}
                        </button>
                    </form>

                    {currentRole === 'patient' && (
                        <p className="mt-8 text-center text-sm text-slate-500">
                            Don't have an account?{' '}
                            <button onClick={() => navigate('/register')} className="text-emerald-600 font-semibold hover:underline">Register Now</button>
                        </p>
                    )}
                </motion.div>
            </div>
        </div>
    );
};

export default Login;
