import React, { useState, useEffect } from 'react';
import { X, Calendar, User, Activity, FileText, Clock, Heart, Thermometer, Info } from 'lucide-react';
import { doctorService } from '../../services/doctorService'; // Ensure this matches export
import { nurseService } from '../../services/nurseService'; // For getVitals
import { prescriptionService } from '../../services/prescriptionService';

const AppointmentDetails = ({ isOpen, onClose, appointment }) => {
    const [vitals, setVitals] = useState(null);
    const [prescription, setPrescription] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (isOpen && appointment) {
            fetchDetails();
        } else {
            setVitals(null);
            setPrescription(null);
            setLoading(true);
        }
    }, [isOpen, appointment]);

    const fetchDetails = async () => {
        setLoading(true);
        try {
            // Fetch Vitals
            const vitalsData = await nurseService.getVitals(appointment.patient_id);
            if (vitalsData && vitalsData.length > 0) {
                setVitals(vitalsData[0]); // Get latest
            }

            // Fetch Prescription
            const prescriptionData = await prescriptionService.getPrescription(appointment.id);
            setPrescription(prescriptionData);

        } catch (error) {
            console.error("Error fetching details:", error);
        } finally {
            setLoading(false);
        }
    };

    if (!isOpen || !appointment) return null;

    const API_BASE_URL = 'http://localhost:5000'; // Or from config

    return (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-4xl shadow-xl flex flex-col max-h-[90vh]">
                {/* Header */}
                <div className="flex items-center justify-between p-6 border-b border-slate-100">
                    <div>
                        <h2 className="text-2xl font-bold text-slate-800">Appointment Details</h2>
                        <p className="text-slate-500">
                            {appointment.patient_name} • {appointment.age} yrs • {appointment.gender}
                        </p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
                        <X size={24} />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-8">
                    {loading ? (
                        <div className="flex justify-center py-12">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
                        </div>
                    ) : (
                        <>
                            {/* Appointment Info */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                                    <h3 className="font-semibold text-slate-700 mb-3 flex items-center gap-2">
                                        <Info size={18} /> Symptoms & Reason
                                    </h3>
                                    <p className="text-slate-600">{appointment.symptoms || appointment.reason || 'No symptoms recorded'}</p>
                                </div>
                                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                                    <h3 className="font-semibold text-slate-700 mb-3 flex items-center gap-2">
                                        <Clock size={18} /> Date & Time
                                    </h3>
                                    <p className="text-slate-600">{appointment.date} at {appointment.time}</p>
                                </div>
                            </div>

                            {/* Vitals */}
                            <div>
                                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                                    <Activity className="text-emerald-500" /> Latest Vitals
                                </h3>
                                {vitals ? (
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
                                            <div className="text-sm text-slate-400 mb-1">Blood Pressure</div>
                                            <div className="text-xl font-bold text-slate-700">{vitals.blood_pressure || '--/--'} <span className="text-xs font-normal text-slate-400">mmHg</span></div>
                                        </div>
                                        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
                                            <div className="text-sm text-slate-400 mb-1">Heart Rate</div>
                                            <div className="text-xl font-bold text-slate-700 flex items-center gap-1">
                                                {vitals.heart_rate || '--'} <Heart size={14} className="text-rose-500 fill-rose-500" />
                                                <span className="text-xs font-normal text-slate-400">bpm</span>
                                            </div>
                                        </div>
                                        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
                                            <div className="text-sm text-slate-400 mb-1">Temperature</div>
                                            <div className="text-xl font-bold text-slate-700 flex items-center gap-1">
                                                {vitals.temperature || '--'} <Thermometer size={14} className="text-amber-500" />
                                                <span className="text-xs font-normal text-slate-400">°F</span>
                                            </div>
                                        </div>
                                        <div className="bg-white border border-slate-200 p-4 rounded-xl shadow-sm">
                                            <div className="text-sm text-slate-400 mb-1">SpO2</div>
                                            <div className="text-xl font-bold text-slate-700">{vitals.oxygen_level || '--'} <span className="text-xs font-normal text-slate-400">%</span></div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-slate-400 text-sm italic py-4 bg-slate-50 rounded-xl text-center border-dashed border-2 border-slate-200">
                                        No vitals recorded for this patient.
                                    </div>
                                )}
                            </div>

                            {/* Prescription */}
                            <div>
                                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                                    <FileText className="text-blue-500" /> Prescription
                                </h3>
                                {prescription ? (
                                    <div className="bg-slate-900 rounded-xl overflow-hidden shadow-md">
                                        <img
                                            src={`${API_BASE_URL}/${prescription.image_path}`}
                                            alt="Handwritten Prescription"
                                            className="w-full h-auto max-h-[500px] object-contain bg-white"
                                        />
                                        <div className="p-3 bg-slate-800 text-slate-300 text-xs text-center">
                                            Prescribed on {new Date(prescription.created_at).toLocaleString()}
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-slate-400 text-sm italic py-8 bg-slate-50 rounded-xl text-center border-dashed border-2 border-slate-200">
                                        No prescription has been written yet.
                                    </div>
                                )}
                            </div>
                        </>
                    )}
                </div>

                <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-2xl flex justify-end">
                    <button
                        onClick={onClose}
                        className="px-6 py-2 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors font-medium"
                    >
                        Close
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AppointmentDetails;
