import React, { useRef, useState, useEffect } from 'react';
import SignatureCanvas from 'react-signature-canvas';
import { X, Save, Trash2, PenTool, Eraser, Maximize2, Minimize2 } from 'lucide-react';

const HandwrittenPrescription = ({ isOpen, onClose, onSave, patientName }) => {
    const sigPad = useRef({});
    const [penColor, setPenColor] = useState('black');
    const [isEraser, setIsEraser] = useState(false);
    const [penSize, setPenSize] = useState(2);
    const [isFullScreen, setIsFullScreen] = useState(false);

    // Resize canvas when modal opens or full screen toggles
    useEffect(() => {
        const resizeCanvas = () => {
            if (sigPad.current && sigPad.current.getCanvas()) {
                const canvas = sigPad.current.getCanvas();
                const parent = canvas.parentElement;
                if (parent) {
                    // Save current content
                    const data = sigPad.current.toData();

                    // Resize
                    canvas.width = parent.clientWidth;
                    canvas.height = parent.clientHeight;

                    // Restore content (needs to be redrawn scaled, or just kept as is? 
                    // Usually clear+redraw or just accepting that changing size clears.
                    // Ideally we want to keep drawing. signature_pad clears on resize manually if not handled.
                    // But here we rely on the implementation to handle data.
                    // Re-loading data ensures it persists.
                    sigPad.current.fromData(data);
                }
            }
        };

        // Small delay to allow layout to settle
        const timer = setTimeout(resizeCanvas, 100);
        window.addEventListener('resize', resizeCanvas);

        return () => {
            clearTimeout(timer);
            window.removeEventListener('resize', resizeCanvas);
        };
    }, [isFullScreen, isOpen]);

    if (!isOpen) return null;

    const clear = () => {
        sigPad.current.clear();
    };

    const handleSave = () => {
        if (sigPad.current.isEmpty()) {
            alert("Please write a prescription first.");
            return;
        }
        // Get the canvas content as a blob
        sigPad.current.getCanvas().toBlob((blob) => {
            onSave(blob);
        });
    };

    const toggleEraser = () => {
        setIsEraser(!isEraser);
    };

    return (
        <div className={`fixed inset-0 z-50 flex items-center justify-center ${isFullScreen ? 'bg-white' : 'bg-black/50 p-4'}`}>
            <div className={`bg-white shadow-xl flex flex-col ${isFullScreen ? 'w-full h-full rounded-none' : 'rounded-2xl w-full max-w-4xl max-h-[90vh]'}`}>
                {/* Header */}
                <div className="flex items-center justify-between p-4 border-b border-slate-100">
                    <div>
                        <h2 className="text-xl font-bold text-slate-800">Prescription for {patientName}</h2>
                        <p className="text-sm text-slate-500">Write clearly within the box</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <button
                            onClick={() => setIsFullScreen(!isFullScreen)}
                            className="p-2 hover:bg-slate-100 rounded-full text-slate-500"
                            title={isFullScreen ? "Exit Full Screen" : "Full Screen"}
                        >
                            {isFullScreen ? <Minimize2 size={24} /> : <Maximize2 size={24} />}
                        </button>
                        <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
                            <X size={24} />
                        </button>
                    </div>
                </div>

                {/* Toolbar */}
                <div className="flex items-center gap-4 p-3 bg-slate-50 border-b border-slate-100">
                    <div className="flex items-center gap-2 bg-white p-1 rounded-lg border border-slate-200">
                        <button
                            onClick={() => { setIsEraser(false); setPenColor('black'); }}
                            className={`p-2 rounded-md transition-colors ${!isEraser && penColor === 'black' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:bg-slate-50'}`}
                            title="Black Pen"
                        >
                            <div className="w-4 h-4 rounded-full bg-black border border-slate-300"></div>
                        </button>
                        <button
                            onClick={() => { setIsEraser(false); setPenColor('blue'); }}
                            className={`p-2 rounded-md transition-colors ${!isEraser && penColor === 'blue' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:bg-slate-50'}`}
                            title="Blue Pen"
                        >
                            <div className="w-4 h-4 rounded-full bg-blue-600 border border-slate-300"></div>
                        </button>
                        <button
                            onClick={() => { setIsEraser(false); setPenColor('red'); }}
                            className={`p-2 rounded-md transition-colors ${!isEraser && penColor === 'red' ? 'bg-slate-100 text-slate-900' : 'text-slate-500 hover:bg-slate-50'}`}
                            title="Red Pen"
                        >
                            <div className="w-4 h-4 rounded-full bg-red-600 border border-slate-300"></div>
                        </button>
                    </div>

                    <div className="h-8 w-px bg-slate-300"></div>

                    <button
                        onClick={toggleEraser}
                        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${isEraser ? 'bg-emerald-100 text-emerald-700' : 'text-slate-600 hover:bg-white hover:shadow-sm'}`}
                    >
                        <Eraser size={18} />
                        Eraser
                    </button>

                    <button
                        onClick={clear}
                        className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-white hover:shadow-sm transition-colors ml-auto"
                    >
                        <Trash2 size={18} />
                        Clear All
                    </button>
                </div>

                {/* Canvas */}
                <div className="flex-1 bg-white p-4 overflow-hidden relative cursor-crosshair">
                    {/* Background lines for guidance */}
                    <div className="absolute inset-0 pointer-events-none"
                        style={{
                            backgroundImage: 'linear-gradient(#e2e8f0 1px, transparent 1px)',
                            backgroundSize: '100% 40px',
                            marginTop: '40px'
                        }}>
                    </div>

                    <div className="border-2 border-slate-200 rounded-xl overflow-hidden h-full shadow-inner bg-white">
                        <SignatureCanvas
                            ref={sigPad}
                            penColor={isEraser ? 'white' : penColor}
                            minWidth={isEraser ? 20 : 1}
                            maxWidth={isEraser ? 20 : 2.5}
                            canvasProps={{
                                className: 'w-full h-full block'
                            }}
                            backgroundColor="transparent"
                        />
                    </div>
                </div>

                {/* Footer */}
                <div className="p-4 border-t border-slate-100 flex justify-end gap-3 bg-slate-50 rounded-b-2xl">
                    <button
                        onClick={onClose}
                        className="px-5 py-2.5 text-sm font-semibold text-slate-600 hover:text-slate-800 transition-colors"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 shadow-lg shadow-emerald-200 transition-all transform active:scale-95"
                    >
                        <Save size={18} />
                        Save Prescription
                    </button>
                </div>
            </div>
        </div>
    );
};

export default HandwrittenPrescription;
