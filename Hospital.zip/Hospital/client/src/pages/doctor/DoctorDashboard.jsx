import React, { useState, useEffect } from 'react';
import { Calendar, User, Clock, CheckCircle, Activity, XCircle } from 'lucide-react';
import { doctorService } from '../../services/doctorService';
import HandwrittenPrescription from './HandwrittenPrescription';
import { prescriptionService } from '../../services/prescriptionService';

const DoctorDashboard = () => {
    const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || { name: 'Doctor' });
    const DOCTOR_NAME = user.name;

    const [stats, setStats] = useState({
        total: 0,
        upcoming: 0,
        completed: 0,
        cancelled: 0
    });
    const [loading, setLoading] = useState(true);

    // Prescription Modal State for Dashboard
    const [isPrescriptionOpen, setIsPrescriptionOpen] = useState(false);
    const [selectedPatientForPrescription, setSelectedPatientForPrescription] = useState(null);

    const handleAttendClick = (patient) => {
        setSelectedPatientForPrescription(patient);
        setIsPrescriptionOpen(true);
    };

    const handleSavePrescription = async (blob) => {
        try {
            // Upload prescription
            await prescriptionService.uploadPrescription(selectedPatientForPrescription.id, blob);

            // Then mark as completed
            await doctorService.updateStatus(selectedPatientForPrescription.id, 'completed');

            // Refresh stats or queue if needed (Queue is in child component, might need trigger or just rely on poll/local update if passed down, but for now we rely on LiveQueue refetch or we can pass a refresh handler)
            // Ideally LiveQueue handles its own state, but we need to tell it to remove the item.
            // Since LiveQueue is separate, we can't easily update its state from here unless we lift state.
            // But we can just rely on the modal closing and the user seeing the queue update on next poll?
            // Better: Lift Queue state or pass a callback? 
            // For simplicity in this step, I will implementation the modal in DoctorDashboard and pass the "onSuccess" callback to LiveQueue if needed, OR implement the modal INSIDE LiveQueue.
            // Implementing INSIDE LiveQueue is cleaner.

            alert('Prescription saved and patient marked as completed!');
            setIsPrescriptionOpen(false);
            setSelectedPatientForPrescription(null);
            window.location.reload(); // Simple refresh to update stats and queue for now
        } catch (error) {
            alert('Failed to process: ' + error.message);
        }
    };

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const data = await doctorService.getStats(DOCTOR_NAME);
                setStats(data);
            } catch (error) {
                console.error("Failed to load doctor stats", error);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    const StatCard = ({ title, value, icon: Icon, color, bg }) => (
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className={`p-4 rounded-xl ${bg} ${color}`}>
                <Icon size={24} />
            </div>
            <div>
                <p className="text-slate-500 text-sm font-medium">{title}</p>
                <h3 className="text-2xl font-bold text-slate-800">{loading ? '-' : value}</h3>
            </div>
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto space-y-8">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800">Welcome, {DOCTOR_NAME}</h1>
                    <p className="text-slate-500 mt-1">Here's your schedule overview for today.</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-500 bg-white px-4 py-2 rounded-xl border border-slate-200">
                    <Activity size={16} className="text-emerald-500" />
                    <span>System Online</span>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard
                    title="Total Appointments"
                    value={stats.total}
                    icon={Calendar}
                    color="text-blue-600"
                    bg="bg-blue-50"
                />
                <StatCard
                    title="Scheduled Today"
                    value={stats.upcoming}
                    icon={Clock}
                    color="text-amber-600"
                    bg="bg-amber-50"
                />
                <StatCard
                    title="Patients Seen"
                    value={stats.completed}
                    icon={CheckCircle}
                    color="text-emerald-600"
                    bg="bg-emerald-50"
                />
                <StatCard
                    title="Cancelled"
                    value={stats.cancelled}
                    icon={XCircle}
                    color="text-red-600"
                    bg="bg-red-50"
                />
            </div>

            {/* Live Queue Section */}
            <LiveQueue doctorName={DOCTOR_NAME} onAttend={handleAttendClick} />

            {/* Prescription Modal */}
            <HandwrittenPrescription
                isOpen={isPrescriptionOpen}
                onClose={() => {
                    setIsPrescriptionOpen(false);
                    setSelectedPatientForPrescription(null);
                }}
                onSave={handleSavePrescription}
                patientName={selectedPatientForPrescription?.patient_name || 'Patient'}
            />
        </div>
    );
};

const LiveQueue = ({ doctorName, onAttend }) => {
    const [queue, setQueue] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchQueue = async () => {
            try {
                const data = await doctorService.getLiveQueue(doctorName);
                setQueue(data);
            } catch (error) {
                console.error("Failed to fetch live queue:", error);
            } finally {
                setLoading(false);
            }
        };

        fetchQueue();
        const interval = setInterval(fetchQueue, 30000); // Poll every 30s
        return () => clearInterval(interval);
    }, [doctorName]);

    if (loading) return <div>Loading queue...</div>;

    if (queue.length === 0) {
        return (
            <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User size={32} className="text-slate-400" />
                </div>
                <h3 className="text-lg font-bold text-slate-800">No Patients in Queue</h3>
                <p className="text-slate-500">Patients accepted by nurses for you will appear here.</p>
            </div>
        );
    }

    return (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    <Activity className="text-emerald-500" size={20} />
                    Live Patient Queue
                </h2>
                <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold">
                    {queue.length} Waiting
                </span>
            </div>
            <div className="divide-y divide-slate-100">
                {queue.map((patient) => (
                    <div key={patient.id} className="p-6 hover:bg-slate-50 transition-colors">
                        <div className="flex items-start justify-between">
                            <div className="flex items-start gap-4">
                                <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-lg">
                                    {patient.patient_name.charAt(0)}
                                </div>
                                <div>
                                    <h3 className="font-bold text-slate-800 text-lg">{patient.patient_name}</h3>
                                    <div className="flex items-center gap-4 text-sm text-slate-500 mt-1">
                                        <span>{patient.age} yrs, {patient.gender}</span>
                                        <span>•</span>
                                        <span>Time: {patient.time}</span>
                                    </div>

                                    {/* Vitals Display */}
                                    <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                                        <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                                            <p className="text-xs text-slate-500">BP</p>
                                            <p className="font-semibold text-slate-800">{patient.blood_pressure || '--'}</p>
                                        </div>
                                        <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                                            <p className="text-xs text-slate-500">Heart Rate</p>
                                            <p className="font-semibold text-slate-800">{patient.heart_rate || '--'} bpm</p>
                                        </div>
                                        <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                                            <p className="text-xs text-slate-500">Temp</p>
                                            <p className="font-semibold text-slate-800">{patient.temperature || '--'} °F</p>
                                        </div>
                                        <div className="bg-slate-50 p-2 rounded-lg border border-slate-100">
                                            <p className="text-xs text-slate-500">SpO2</p>
                                            <p className="font-semibold text-slate-800">{patient.oxygen_level || '--'}%</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button
                                className="px-6 py-2 bg-emerald-600 text-white rounded-xl font-semibold hover:bg-emerald-700 shadow-lg shadow-emerald-600/20 transition-all"
                                onClick={() => onAttend(patient)}
                            >
                                Attend
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DoctorDashboard;
