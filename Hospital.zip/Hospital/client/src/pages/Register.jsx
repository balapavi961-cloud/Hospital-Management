import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Lock, Mail, Phone, ArrowRight, Building2, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import FloatingInput from '../components/ui/FloatingInput';

const Register = () => {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);

    // Form State
    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        phone: '',
        password: '',
        confirmPassword: ''
    });
    const [errors, setErrors] = useState({});

    const validate = () => {
        const newErrors = {};
        if (!formData.fullName) newErrors.fullName = 'Full Name is required';
        if (!formData.email) newErrors.email = 'Email is required';
        if (!formData.phone) newErrors.phone = 'Phone Number is required';
        if (!formData.password) newErrors.password = 'Password is required';
        if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;

        setIsLoading(true);
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        setIsLoading(false);
        // Navigate to login after success (or dashboard)
        navigate('/login/patient');
    };

    return (
        <div className="min-h-screen w-full flex bg-slate-50 overflow-hidden">

            {/* LEFT SIDE: Branding & Info */}
            <div className="hidden md:flex w-1/3 min-w-[320px] bg-slate-900 text-white flex-col relative overflow-hidden p-8 justify-between">
                {/* Background Decor */}
                <div className="absolute top-0 left-0 w-full h-full opacity-20 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-teal-500 via-emerald-600 to-slate-900" />
                <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-emerald-500 rounded-full blur-[100px] opacity-20" />

                {/* Branding */}
                <div className="relative z-10 flex items-center gap-3">
                    <div className="p-2 bg-emerald-600 rounded-lg">
                        <Building2 size={24} className="text-white" />
                    </div>
                    <div>
                        <h1 className="text-xl font-bold tracking-tight">MediCare<span className="text-emerald-400">Plus</span></h1>
                        <p className="text-xs text-slate-400">Hospital Management System</p>
                    </div>
                </div>

                {/* Content */}
                <div className="relative z-10 my-auto">
                    <h2 className="text-3xl font-bold mb-6">Join our Community</h2>
                    <p className="text-slate-400 mb-8 leading-relaxed">
                        Create an account to manage your appointments, view medical history, and connect with top doctors.
                    </p>

                    <div className="space-y-4">
                        <div className="flex items-center gap-3 text-sm text-slate-300">
                            <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><CheckCircle size={16} /></div>
                            <span>Book appointments easier</span>
                        </div>
                        <div className="flex items-center gap-3 text-sm text-slate-300">
                            <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><CheckCircle size={16} /></div>
                            <span>Access medical records</span>
                        </div>
                        <div className="flex items-center gap-3 text-sm text-slate-300">
                            <div className="p-1 bg-emerald-500/20 rounded-full text-emerald-400"><CheckCircle size={16} /></div>
                            <span>24/7 Support</span>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="relative z-10 text-xs text-slate-500">
                    &copy; 2024 MediCarePlus. All rights reserved.
                </div>
            </div>

            {/* RIGHT SIDE: Register Form */}
            <div className="flex-1 flex items-center justify-center p-4 md:p-8 relative bg-white md:bg-slate-50">
                {/* Mobile Header */}
                <div className="absolute top-6 left-6 md:hidden flex items-center gap-2 text-slate-800">
                    <Building2 size={24} className="text-emerald-600" />
                    <span className="font-bold">MediCare+</span>
                </div>

                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="w-full max-w-md bg-white md:shadow-xl md:rounded-2xl p-8 md:p-12 border-slate-100"
                >
                    <div className="text-center mb-10">
                        <h2 className="text-3xl font-bold text-slate-800 mb-2">Create Account</h2>
                        <p className="text-slate-500">Sign up as a new patient</p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-5">
                        <FloatingInput
                            id="fullName"
                            label="Full Name"
                            icon={User}
                            value={formData.fullName}
                            onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                            error={errors.fullName}
                            className="bg-slate-50 border-slate-200 focus:border-emerald-500 text-slate-800"
                        />

                        <FloatingInput
                            id="email"
                            label="Email Address"
                            icon={Mail}
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            error={errors.email}
                            className="bg-slate-50 border-slate-200 focus:border-emerald-500 text-slate-800"
                        />

                        <FloatingInput
                            id="phone"
                            label="Phone Number"
                            icon={Phone}
                            value={formData.phone}
                            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                            error={errors.phone}
                            className="bg-slate-50 border-slate-200 focus:border-emerald-500 text-slate-800"
                        />

                        <FloatingInput
                            id="password"
                            type="password"
                            label="Password"
                            icon={Lock}
                            value={formData.password}
                            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                            error={errors.password}
                            className="bg-slate-50 border-slate-200 focus:border-emerald-500 text-slate-800"
                        />

                        <FloatingInput
                            id="confirmPassword"
                            type="password"
                            label="Confirm Password"
                            icon={Lock}
                            value={formData.confirmPassword}
                            onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                            error={errors.confirmPassword}
                            className="bg-slate-50 border-slate-200 focus:border-emerald-500 text-slate-800"
                        />

                        <button
                            type="submit"
                            className="w-full py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-semibold shadow-lg shadow-slate-900/20 transition-all flex items-center justify-center gap-2 mt-4"
                        >
                            {isLoading ? 'Creating Account...' : 'Register'}
                            {!isLoading && <ArrowRight size={18} />}
                        </button>
                    </form>

                    <p className="mt-8 text-center text-sm text-slate-500">
                        Already have an account?{' '}
                        <button onClick={() => navigate('/login/patient')} className="text-emerald-600 font-semibold hover:underline">
                            Login here
                        </button>
                    </p>
                </motion.div>
            </div>
        </div>
    );
};

export default Register;
