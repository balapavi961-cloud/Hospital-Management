import React, { useState, useRef, useEffect } from 'react';
import { Outlet, NavLink, useNavigate, useLocation } from 'react-router-dom';
import {
    LayoutDashboard,
    CalendarPlus,
    History,
    Settings,
    LogOut,
    Menu,
    Bell,
    User,
    Building2, // Hospital Icon
    Activity,
    Calendar, // Added Calendar
    CheckCircle
} from 'lucide-react';

const DashboardLayout = () => {
    const location = useLocation();
    const navigate = useNavigate();

    // Extract role from path (e.g. /dashboard/patient -> patient)
    const role = location.pathname.split('/')[2] || 'patient';

    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
    const userMenuRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
                setIsUserMenuOpen(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    // Todo: Move to config/nav.js later if it grows
    const navItems = {
        patient: [
            { icon: LayoutDashboard, label: 'Overview', path: `/dashboard/patient` },
            { icon: CalendarPlus, label: 'Book Appointment', path: `/dashboard/patient/book` },
        ],
        nurse: [
            { icon: CalendarPlus, label: 'Appointments', path: `/dashboard/nurse/appointments` },
            { icon: Calendar, label: 'Book Appointment', path: `/dashboard/nurse/book` },

        ],
        receptionist: [
            { icon: CalendarPlus, label: 'Front Desk', path: `/dashboard/receptionist/appointments` },
            { icon: Calendar, label: 'Book Appointment', path: `/dashboard/receptionist/book` },
            { icon: History, label: 'Daily Log', path: `/dashboard/receptionist/log` },
        ],
        admin: [
            { icon: LayoutDashboard, label: 'Dashboard', path: `/dashboard/admin` },
            { icon: User, label: 'Staff', path: `/dashboard/admin/staff` },
            { icon: Building2, label: 'Departments', path: `/dashboard/admin/departments` },
        ],
        doctor: [
            { icon: LayoutDashboard, label: 'Dashboard', path: `/dashboard/doctor` },
            { icon: CalendarPlus, label: 'My Schedule', path: `/dashboard/doctor/appointments` },
            { icon: CheckCircle, label: 'Completed', path: `/dashboard/doctor/completed` },
        ],
        // Add other roles later
    };

    const currentNav = navItems[role] || navItems.patient;

    return (
        <div className="min-h-screen bg-slate-50 flex">
            {/* Sidebar */}
            <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transform transition-transform duration-300 ease-in-out
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0
      `}>
                <div className="p-6">
                    <div className="flex items-center gap-3 mb-8">
                        <div className="p-2 bg-emerald-600 rounded-lg">
                            <Building2 size={20} className="text-white" />
                        </div>
                        <span className="text-lg font-bold">MediCare+</span>
                    </div>

                    <nav className="space-y-2">
                        {currentNav.map((item) => (
                            <NavLink
                                key={item.path}
                                to={item.path}
                                end // Force exact match so Overview isn't active when on sub-pages
                                className={({ isActive }) => `
                  flex items-center gap-3 px-4 py-3 rounded-xl transition-all
                  ${isActive
                                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/20'
                                        : 'text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'}
                `}
                            >
                                <item.icon size={20} />
                                <span className="font-medium">{item.label}</span>
                            </NavLink>
                        ))}
                    </nav>


                </div>
            </aside>

            {/* Main Content */}
            <div className="flex-1 flex flex-col min-w-0">
                {/* Header */}
                <header className="bg-white border-b border-slate-200 h-16 px-6 flex items-center justify-between sticky top-0 z-40">
                    <button
                        className="md:hidden p-2 text-slate-600"
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                    >
                        <Menu size={24} />
                    </button>

                    <div className="ml-auto flex items-center gap-4">
                        <button className="p-2 text-slate-400 hover:text-blue-600 transition-colors relative">
                            <Bell size={20} />
                            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
                        </button>

                        <div className="relative" ref={userMenuRef}>
                            <button
                                onClick={() => {
                                    setIsMobileMenuOpen(false); // Close mobile menu if open
                                    setIsUserMenuOpen(!isUserMenuOpen);
                                }}
                                className="flex items-center gap-3 pl-4 border-l border-slate-200 focus:outline-none"
                            >
                                <div className="text-right hidden sm:block">
                                    <p className="text-sm font-semibold text-slate-700">John Doe</p>
                                    <p className="text-xs text-slate-500 capitalize">{role}</p>
                                </div>
                                <div className="w-10 h-10 rounded-full bg-slate-200 border-2 border-white shadow-sm flex items-center justify-center overflow-hidden hover:border-blue-400 transition-colors">
                                    <User size={20} className="text-slate-500" />
                                </div>
                            </button>

                            {/* User Dropdown Menu */}
                            {isUserMenuOpen && (
                                <div className="absolute right-0 top-12 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50">
                                    <div className="px-4 py-2 border-b border-slate-50 sm:hidden">
                                        <p className="text-sm font-semibold text-slate-700">John Doe</p>
                                    </div>

                                    {role !== 'nurse' && role !== 'receptionist' && (
                                        <button
                                            onClick={() => {
                                                navigate(`/dashboard/${role}/profile`);
                                                setIsUserMenuOpen(false);
                                            }}
                                            className="w-full flex items-center gap-3 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-blue-600 transition-colors"
                                        >
                                            <User size={16} />
                                            My Profile
                                        </button>
                                    )}

                                    <button
                                        className="w-full flex items-center gap-3 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-blue-600 transition-colors"
                                    >
                                        <Settings size={16} />
                                        Settings
                                    </button>

                                    <div className="h-px bg-slate-100 my-1" />

                                    <button
                                        onClick={() => navigate('/login/patient')}
                                        className="w-full flex items-center gap-3 px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
                                    >
                                        <LogOut size={16} />
                                        Sign Out
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </header>

                {/* Page Content */}
                <main className="flex-1 overflow-y-auto p-6">
                    <Outlet />
                </main>
            </div >

            {/* Mobile Overlay */}
            {
                isMobileMenuOpen && (
                    <div
                        className="fixed inset-0 bg-black/50 z-40 md:hidden"
                        onClick={() => setIsMobileMenuOpen(false)}
                    />
                )
            }
        </div >
    );
};

export default DashboardLayout;
